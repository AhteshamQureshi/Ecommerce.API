using Ecommerce.API.Models;

namespace Ecommerce.API.Data;

/// <summary>
/// Central in-memory data store. Replace with DbContext when migrating to EF Core + SQL Server.
/// </summary>
public static class DataStore
{
    // ── Users ────────────────────────────────────────────────────────────────
    public static List<User> Users { get; } =
    [
        new() { Id = 1, FirstName = "Alice",  LastName = "Johnson", Email = "alice@example.com",  PasswordHash = HashPassword("password123"), Role = "Admin",    Phone = "555-0101", Address = "123 Main St, New York, NY 10001",       CreatedAt = DateTime.UtcNow.AddDays(-90) },
        new() { Id = 2, FirstName = "Bob",    LastName = "Smith",   Email = "bob@example.com",    PasswordHash = HashPassword("password123"), Role = "Customer", Phone = "555-0102", Address = "456 Oak Ave, Los Angeles, CA 90001",   CreatedAt = DateTime.UtcNow.AddDays(-60) },
        new() { Id = 3, FirstName = "Carol",  LastName = "Davis",   Email = "carol@example.com",  PasswordHash = HashPassword("password123"), Role = "Customer", Phone = "555-0103", Address = "789 Pine Rd, Chicago, IL 60601",        CreatedAt = DateTime.UtcNow.AddDays(-30) },
        new() { Id = 4, FirstName = "David",  LastName = "Wilson",  Email = "david@example.com",  PasswordHash = HashPassword("password123"), Role = "Customer", Phone = "555-0104", Address = "321 Elm St, Houston, TX 77001",         CreatedAt = DateTime.UtcNow.AddDays(-15) },
        new() { Id = 5, FirstName = "Emma",   LastName = "Brown",   Email = "emma@example.com",   PasswordHash = HashPassword("password123"), Role = "Customer", Phone = "555-0105", Address = "654 Maple Dr, Phoenix, AZ 85001",       CreatedAt = DateTime.UtcNow.AddDays(-7)  },
    ];

    // ── Categories ───────────────────────────────────────────────────────────
    public static List<Category> Categories { get; } =
    [
        new() { Id = 1, Name = "Electronics",     Description = "Gadgets, phones, laptops and more",       ImageUrl = "https://placehold.co/400x300?text=Electronics"     },
        new() { Id = 2, Name = "Clothing",         Description = "Fashion for men, women and kids",          ImageUrl = "https://placehold.co/400x300?text=Clothing"         },
        new() { Id = 3, Name = "Books",             Description = "Fiction, non-fiction, textbooks",          ImageUrl = "https://placehold.co/400x300?text=Books"             },
        new() { Id = 4, Name = "Home & Kitchen",    Description = "Furniture, appliances and décor",          ImageUrl = "https://placehold.co/400x300?text=Home+Kitchen"      },
        new() { Id = 5, Name = "Sports & Outdoors", Description = "Equipment and gear for every sport",       ImageUrl = "https://placehold.co/400x300?text=Sports"            },
        new() { Id = 6, Name = "Toys & Games",      Description = "Fun for all ages",                         ImageUrl = "https://placehold.co/400x300?text=Toys"              },
    ];

    // ── Products ─────────────────────────────────────────────────────────────
    public static List<Product> Products { get; } =
    [
        // Electronics
        new() { Id = 1,  Name = "iPhone 16 Pro",          Description = "Latest Apple flagship with A18 chip",          Price = 999.99m,  DiscountPrice = 949.99m, Stock = 50,  CategoryId = 1, Brand = "Apple",    ImageUrl = "https://placehold.co/400?text=iPhone16Pro",    Rating = 4.8, ReviewCount = 1240 },
        new() { Id = 2,  Name = "Samsung Galaxy S25",      Description = "Android powerhouse with 200MP camera",         Price = 899.99m,  DiscountPrice = null,    Stock = 35,  CategoryId = 1, Brand = "Samsung",  ImageUrl = "https://placehold.co/400?text=GalaxyS25",      Rating = 4.7, ReviewCount = 980  },
        new() { Id = 3,  Name = "MacBook Pro 14\"",        Description = "M4 chip, 16GB RAM, 512GB SSD",                 Price = 1999.00m, DiscountPrice = null,    Stock = 20,  CategoryId = 1, Brand = "Apple",    ImageUrl = "https://placehold.co/400?text=MacBookPro",     Rating = 4.9, ReviewCount = 620  },
        new() { Id = 4,  Name = "Sony WH-1000XM6",         Description = "Industry-leading noise-cancelling headphones", Price = 399.99m,  DiscountPrice = 349.99m, Stock = 80,  CategoryId = 1, Brand = "Sony",     ImageUrl = "https://placehold.co/400?text=SonyWH1000XM6",  Rating = 4.8, ReviewCount = 3200 },
        new() { Id = 5,  Name = "Dell 27\" 4K Monitor",    Description = "UHD IPS panel, 144Hz refresh rate",            Price = 549.00m,  DiscountPrice = 499.00m, Stock = 30,  CategoryId = 1, Brand = "Dell",     ImageUrl = "https://placehold.co/400?text=DellMonitor",    Rating = 4.6, ReviewCount = 450  },

        // Clothing
        new() { Id = 6,  Name = "Classic White T-Shirt",   Description = "100% organic cotton, relaxed fit",             Price = 29.99m,   DiscountPrice = null,    Stock = 200, CategoryId = 2, Brand = "H&M",      ImageUrl = "https://placehold.co/400?text=WhiteTShirt",    Rating = 4.3, ReviewCount = 870  },
        new() { Id = 7,  Name = "Slim-Fit Jeans",           Description = "Stretch denim, available in multiple washes",  Price = 79.99m,   DiscountPrice = 59.99m,  Stock = 150, CategoryId = 2, Brand = "Levi's",   ImageUrl = "https://placehold.co/400?text=SlimJeans",      Rating = 4.5, ReviewCount = 1100 },
        new() { Id = 8,  Name = "Running Sneakers",         Description = "Lightweight mesh upper, cushioned sole",       Price = 119.99m,  DiscountPrice = null,    Stock = 90,  CategoryId = 2, Brand = "Nike",     ImageUrl = "https://placehold.co/400?text=Sneakers",       Rating = 4.6, ReviewCount = 760  },

        // Books
        new() { Id = 9,  Name = "Clean Code",              Description = "A handbook of agile software craftsmanship",   Price = 45.00m,   DiscountPrice = 39.00m,  Stock = 100, CategoryId = 3, Brand = "Pearson",  ImageUrl = "https://placehold.co/400?text=CleanCode",      Rating = 4.9, ReviewCount = 5400 },
        new() { Id = 10, Name = "The Pragmatic Programmer", Description = "Your journey to mastery, 20th anniversary ed",Price = 49.99m,   DiscountPrice = null,    Stock = 75,  CategoryId = 3, Brand = "Addison",  ImageUrl = "https://placehold.co/400?text=PragProg",       Rating = 4.8, ReviewCount = 3100 },

        // Home & Kitchen
        new() { Id = 11, Name = "Instant Pot Duo 7-in-1",  Description = "Electric pressure cooker, 6-quart",            Price = 89.99m,   DiscountPrice = 69.99m,  Stock = 60,  CategoryId = 4, Brand = "Instant",  ImageUrl = "https://placehold.co/400?text=InstantPot",     Rating = 4.7, ReviewCount = 12000},
        new() { Id = 12, Name = "Dyson V15 Vacuum",         Description = "Cordless vacuum with laser dust detection",    Price = 749.99m,  DiscountPrice = null,    Stock = 25,  CategoryId = 4, Brand = "Dyson",    ImageUrl = "https://placehold.co/400?text=DysonV15",       Rating = 4.8, ReviewCount = 2300 },

        // Sports
        new() { Id = 13, Name = "Yoga Mat Pro",             Description = "Non-slip, eco-friendly, 6mm thick",            Price = 59.99m,   DiscountPrice = null,    Stock = 120, CategoryId = 5, Brand = "Gaiam",    ImageUrl = "https://placehold.co/400?text=YogaMat",        Rating = 4.5, ReviewCount = 890  },
        new() { Id = 14, Name = "Adjustable Dumbbells Set", Description = "5–52.5 lbs, space-saving design",             Price = 349.00m,  DiscountPrice = 299.00m, Stock = 40,  CategoryId = 5, Brand = "Bowflex",  ImageUrl = "https://placehold.co/400?text=Dumbbells",      Rating = 4.7, ReviewCount = 1500 },

        // Toys
        new() { Id = 15, Name = "LEGO Technic Bugatti",     Description = "3599-piece supercar model, 1:8 scale",         Price = 449.99m,  DiscountPrice = 399.99m, Stock = 15,  CategoryId = 6, Brand = "LEGO",     ImageUrl = "https://placehold.co/400?text=LEGOBugatti",    Rating = 4.9, ReviewCount = 640  },
    ];

    // ── Cart Items ───────────────────────────────────────────────────────────
    public static List<CartItem> CartItems { get; } =
    [
        new() { Id = 1, UserId = 2, ProductId = 1, Quantity = 1 },
        new() { Id = 2, UserId = 2, ProductId = 9, Quantity = 2 },
        new() { Id = 3, UserId = 3, ProductId = 4, Quantity = 1 },
    ];

    // ── Orders ───────────────────────────────────────────────────────────────
    public static List<Order> Orders { get; } =
    [
        new()
        {
            Id = 1, UserId = 2, Status = "Delivered", PaymentStatus = "Paid",
            ShippingAddress = "456 Oak Ave, Los Angeles, CA 90001", PaymentMethod = "Credit Card",
            TotalAmount = 1089.98m, OrderDate = DateTime.UtcNow.AddDays(-20), DeliveredAt = DateTime.UtcNow.AddDays(-15),
            Items =
            [
                new() { Id = 1, OrderId = 1, ProductId = 1, ProductName = "iPhone 16 Pro",    Quantity = 1, UnitPrice = 949.99m },
                new() { Id = 2, OrderId = 1, ProductId = 9, ProductName = "Clean Code",        Quantity = 3, UnitPrice = 39.99m  },
            ]
        },
        new()
        {
            Id = 2, UserId = 3, Status = "Processing", PaymentStatus = "Paid",
            ShippingAddress = "789 Pine Rd, Chicago, IL 60601", PaymentMethod = "PayPal",
            TotalAmount = 349.99m, OrderDate = DateTime.UtcNow.AddDays(-2),
            Items =
            [
                new() { Id = 3, OrderId = 2, ProductId = 4, ProductName = "Sony WH-1000XM6", Quantity = 1, UnitPrice = 349.99m },
            ]
        },
    ];

    // ── Wishlist ─────────────────────────────────────────────────────────────
    public static List<WishlistItem> WishlistItems { get; } =
    [
        new() { Id = 1, UserId = 2, ProductId = 3  },
        new() { Id = 2, UserId = 2, ProductId = 11 },
        new() { Id = 3, UserId = 3, ProductId = 1  },
        new() { Id = 4, UserId = 3, ProductId = 15 },
    ];

    // ── Counters (auto-increment simulation) ─────────────────────────────────
    public static int NextUserId      => Users.Count > 0 ? Users.Max(u => u.Id) + 1 : 1;
    public static int NextProductId   => Products.Count > 0 ? Products.Max(p => p.Id) + 1 : 1;
    public static int NextCategoryId  => Categories.Count > 0 ? Categories.Max(c => c.Id) + 1 : 1;
    public static int NextCartItemId  => CartItems.Count > 0 ? CartItems.Max(c => c.Id) + 1 : 1;
    public static int NextOrderId     => Orders.Count > 0 ? Orders.Max(o => o.Id) + 1 : 1;
    public static int NextWishlistId  => WishlistItems.Count > 0 ? WishlistItems.Max(w => w.Id) + 1 : 1;

    // Simple password hashing (use BCrypt in production)
    public static string HashPassword(string password) =>
        Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(password));

    public static bool VerifyPassword(string password, string hash) =>
        HashPassword(password) == hash;
}
