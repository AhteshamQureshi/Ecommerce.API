namespace Ecommerce.API.DTOs.Cart;

public class CartItemDto
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string ProductImage { get; set; } = string.Empty;
    public string Brand { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }
    public decimal TotalPrice => UnitPrice * Quantity;
    public int AvailableStock { get; set; }
}

public class CartSummaryDto
{
    public List<CartItemDto> Items { get; set; } = [];
    public int TotalItems => Items.Sum(i => i.Quantity);
    public decimal SubTotal => Items.Sum(i => i.TotalPrice);
    public decimal ShippingCost => SubTotal >= 500 ? 0 : 9.99m;
    public decimal Tax => Math.Round(SubTotal * 0.08m, 2);
    public decimal GrandTotal => SubTotal + ShippingCost + Tax;
}

public class AddToCartRequest
{
    public int ProductId { get; set; }
    public int Quantity { get; set; } = 1;
}

public class UpdateCartItemRequest
{
    public int Quantity { get; set; }
}
