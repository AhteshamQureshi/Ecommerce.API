namespace Ecommerce.API.DTOs.Wishlist;

public class WishlistItemDto
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string ProductImage { get; set; } = string.Empty;
    public string Brand { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public decimal? DiscountPrice { get; set; }
    public bool InStock { get; set; }
    public double Rating { get; set; }
    public DateTime AddedAt { get; set; }
}

public class AddToWishlistRequest
{
    public int ProductId { get; set; }
}
