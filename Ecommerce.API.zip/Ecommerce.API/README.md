# 🛒 Ecommerce API — ASP.NET Core 10 Monolith

A beginner-friendly, fully-working ecommerce REST API built with **.NET 10 / ASP.NET Core Web API**.  
Uses **in-memory dummy data** — no database required to run. Ready to migrate to EF Core + SQL Server later.

---

## 📁 Project Structure

```
Ecommerce.API/
├── Controllers/
│   ├── BaseController.cs          # Shared helpers (ToActionResult, GetCurrentUserId)
│   ├── AuthController.cs          # POST /api/auth/register, /login
│   ├── UsersController.cs         # GET/PUT /api/users
│   ├── CategoriesController.cs    # CRUD /api/categories
│   ├── ProductsController.cs      # CRUD + filter/search /api/products
│   ├── CartController.cs          # GET/POST/PUT/DELETE /api/cart
│   ├── OrdersController.cs        # GET/POST /api/orders
│   └── WishlistController.cs      # GET/POST/DELETE /api/wishlist
│
├── Services/
│   ├── Interfaces/IServices.cs    # All service contracts
│   ├── ServiceResult.cs           # Generic success/failure wrapper
│   ├── AuthService.cs
│   ├── UserService.cs
│   ├── CategoryService.cs
│   ├── ProductService.cs
│   ├── CartService.cs
│   ├── OrderService.cs
│   └── WishlistService.cs
│
├── Models/                        # Domain models (→ EF Core entities later)
│   ├── User.cs
│   ├── Category.cs
│   ├── Product.cs
│   └── OrderModels.cs             # Order, OrderItem, CartItem, WishlistItem
│
├── DTOs/                          # Request/Response shapes
│   ├── Auth/AuthDtos.cs
│   ├── User/UserDtos.cs
│   ├── Category/CategoryDtos.cs
│   ├── Product/ProductDtos.cs
│   ├── Cart/CartDtos.cs
│   ├── Order/OrderDtos.cs
│   └── Wishlist/WishlistDtos.cs
│
├── Data/
│   └── DataStore.cs               # In-memory collections + dummy seed data
│
├── Middleware/
│   └── ExceptionHandlingMiddleware.cs
│
├── Extensions/
│   └── ServiceExtensions.cs       # DI registration + JWT + Swagger config
│
├── Program.cs
├── appsettings.json
└── Ecommerce.API.csproj
```

---

## 🚀 Getting Started

### Prerequisites
- [.NET 10 SDK](https://dotnet.microsoft.com/download)

### Run the API
```bash
cd Ecommerce.API
dotnet run
```

The API starts at `http://localhost:5000`.  
Swagger UI opens automatically at **`http://localhost:5000`** (root URL).

---

## 🔐 Authentication

The API uses **JWT Bearer tokens**.

### Test credentials (from dummy data)

| Email | Password | Role |
|---|---|---|
| alice@example.com | password123 | **Admin** |
| bob@example.com | password123 | Customer |
| carol@example.com | password123 | Customer |

### Login flow
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "bob@example.com",
  "password": "password123"
}
```

Copy the returned `token` and use it as:
```
Authorization: Bearer <your-token>
```

In **Swagger UI**, click **Authorize** (top right) and enter `Bearer <token>`.

---

## 📋 API Endpoints

### Auth
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | ❌ | Register a new customer |
| POST | `/api/auth/login` | ❌ | Login and receive a JWT token |

### Users
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/users` | 🔑 Admin | List all users |
| GET | `/api/users/me` | 🔑 | Get own profile |
| GET | `/api/users/{id}` | 🔑 | Get user by ID |
| PUT | `/api/users/{id}` | 🔑 | Update profile |
| POST | `/api/users/{id}/change-password` | 🔑 | Change password |
| DELETE | `/api/users/{id}` | 🔑 Admin | Deactivate user |

### Categories
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/categories` | ❌ | List all categories |
| GET | `/api/categories/{id}` | ❌ | Get category by ID |
| POST | `/api/categories` | 🔑 Admin | Create category |
| PUT | `/api/categories/{id}` | 🔑 Admin | Update category |
| DELETE | `/api/categories/{id}` | 🔑 Admin | Delete category |

### Products
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/products` | ❌ | List products (filter + paginate) |
| GET | `/api/products/{id}` | ❌ | Get product by ID |
| GET | `/api/products/category/{categoryId}` | ❌ | Products by category |
| POST | `/api/products` | 🔑 Admin | Create product |
| PUT | `/api/products/{id}` | 🔑 Admin | Update product |
| DELETE | `/api/products/{id}` | 🔑 Admin | Delete product |

**Product filter query parameters:**
```
?search=iphone&categoryId=1&brand=Apple&minPrice=100&maxPrice=2000
&sortBy=price&sortOrder=asc&page=1&pageSize=10
```

### Cart
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/cart` | 🔑 | View cart with totals |
| POST | `/api/cart/items` | 🔑 | Add item to cart |
| PUT | `/api/cart/items/{id}` | 🔑 | Update item quantity |
| DELETE | `/api/cart/items/{id}` | 🔑 | Remove single item |
| DELETE | `/api/cart` | 🔑 | Clear entire cart |

### Orders
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/orders` | 🔑 | My orders |
| GET | `/api/orders/all` | 🔑 Admin | All orders |
| GET | `/api/orders/{id}` | 🔑 | Get order by ID |
| POST | `/api/orders` | 🔑 | Place order (from cart) |
| PATCH | `/api/orders/{id}/status` | 🔑 Admin | Update order status |
| POST | `/api/orders/{id}/cancel` | 🔑 | Cancel order |

### Wishlist
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/wishlist` | 🔑 | View wishlist |
| POST | `/api/wishlist/items` | 🔑 | Add to wishlist |
| DELETE | `/api/wishlist/items/{id}` | 🔑 | Remove from wishlist |
| DELETE | `/api/wishlist` | 🔑 | Clear wishlist |
| POST | `/api/wishlist/items/{id}/move-to-cart` | 🔑 | Move item to cart |

---

## 🔄 Migrating to EF Core + SQL Server

When you're ready to use a real database:

1. Add NuGet packages:
   ```bash
   dotnet add package Microsoft.EntityFrameworkCore.SqlServer
   dotnet add package Microsoft.EntityFrameworkCore.Tools
   ```

2. Create `AppDbContext` inheriting `DbContext`, with `DbSet<T>` for each model.

3. Replace `DataStore.*` references in each service with injected `AppDbContext`.

4. Run:
   ```bash
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```

All models are already structured to work directly as EF Core entities.

---

## 🏗️ Architecture Notes

- **ServiceResult\<T\>** — avoids exception-driven flow for business errors; controllers convert it to proper HTTP responses via `ToActionResult()`.
- **Soft deletes** — Users, Products, and Categories are deactivated (`IsActive = false`) rather than hard-deleted.
- **Stock management** — Placing an order deducts stock; cancelling restores it.
- **Passwords** — Currently Base64-encoded for simplicity. Replace `DataStore.HashPassword` with BCrypt (`BCrypt.Net.BCrypt.HashPassword`) in production.
- **JWT** — 24-hour expiry, configurable in `appsettings.json`.
