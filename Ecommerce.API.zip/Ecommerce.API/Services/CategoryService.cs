using Ecommerce.API.Data;
using Ecommerce.API.DTOs.Category;
using Ecommerce.API.Models;
using Ecommerce.API.Services.Interfaces;

namespace Ecommerce.API.Services;

public class CategoryService : ICategoryService
{
    public Task<ServiceResult<List<CategoryDto>>> GetAllCategoriesAsync()
    {
        var categories = DataStore.Categories
            .Where(c => c.IsActive)
            .Select(MapToDto)
            .ToList();

        return Task.FromResult(ServiceResult<List<CategoryDto>>.Success(categories));
    }

    public Task<ServiceResult<CategoryDto>> GetCategoryByIdAsync(int id)
    {
        var category = DataStore.Categories.FirstOrDefault(c => c.Id == id && c.IsActive);
        if (category is null)
            return Task.FromResult(ServiceResult<CategoryDto>.NotFound($"Category {id} not found."));

        return Task.FromResult(ServiceResult<CategoryDto>.Success(MapToDto(category)));
    }

    public Task<ServiceResult<CategoryDto>> CreateCategoryAsync(CreateCategoryRequest request)
    {
        if (DataStore.Categories.Any(c => c.Name.Equals(request.Name, StringComparison.OrdinalIgnoreCase)))
            return Task.FromResult(ServiceResult<CategoryDto>.Failure("A category with this name already exists."));

        var category = new Category
        {
            Id = DataStore.NextCategoryId,
            Name = request.Name,
            Description = request.Description,
            ImageUrl = request.ImageUrl,
            CreatedAt = DateTime.UtcNow
        };

        DataStore.Categories.Add(category);
        return Task.FromResult(ServiceResult<CategoryDto>.Success(MapToDto(category), 201));
    }

    public Task<ServiceResult<CategoryDto>> UpdateCategoryAsync(int id, UpdateCategoryRequest request)
    {
        var category = DataStore.Categories.FirstOrDefault(c => c.Id == id);
        if (category is null)
            return Task.FromResult(ServiceResult<CategoryDto>.NotFound($"Category {id} not found."));

        category.Name = request.Name;
        category.Description = request.Description;
        category.ImageUrl = request.ImageUrl;
        category.IsActive = request.IsActive;

        return Task.FromResult(ServiceResult<CategoryDto>.Success(MapToDto(category)));
    }

    public Task<ServiceResult<bool>> DeleteCategoryAsync(int id)
    {
        var category = DataStore.Categories.FirstOrDefault(c => c.Id == id);
        if (category is null)
            return Task.FromResult(ServiceResult<bool>.NotFound($"Category {id} not found."));

        if (DataStore.Products.Any(p => p.CategoryId == id && p.IsActive))
            return Task.FromResult(ServiceResult<bool>.Failure("Cannot delete a category that has active products."));

        category.IsActive = false;
        return Task.FromResult(ServiceResult<bool>.Success(true));
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private static CategoryDto MapToDto(Category c) => new()
    {
        Id = c.Id,
        Name = c.Name,
        Description = c.Description,
        ImageUrl = c.ImageUrl,
        IsActive = c.IsActive,
        ProductCount = DataStore.Products.Count(p => p.CategoryId == c.Id && p.IsActive)
    };
}
