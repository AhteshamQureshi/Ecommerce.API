using Ecommerce.API.Data;
using Ecommerce.API.DTOs.Cart;
using Ecommerce.API.DTOs.Wishlist;
using Ecommerce.API.Models;
using Ecommerce.API.Services.Interfaces;

namespace Ecommerce.API.Services;

public class WishlistService(ICartService cartService) : IWishlistService
{
    public Task<ServiceResult<List<WishlistItemDto>>> GetWishlistAsync(int userId)
    {
        var items = DataStore.WishlistItems
            .Where(w => w.UserId == userId)
            .Select(w =>
            {
                var product = DataStore.Products.FirstOrDefault(p => p.Id == w.ProductId);
                return product is null ? null : new WishlistItemDto
                {
                    Id = w.Id,
                    ProductId = product.Id,
                    ProductName = product.Name,
                    ProductImage = product.ImageUrl,
                    Brand = product.Brand,
                    Price = product.Price,
                    DiscountPrice = product.DiscountPrice,
                    InStock = product.Stock > 0,
                    Rating = product.Rating,
                    AddedAt = w.AddedAt
                };
            })
            .Where(i => i is not null)
            .Cast<WishlistItemDto>()
            .ToList();

        return Task.FromResult(ServiceResult<List<WishlistItemDto>>.Success(items));
    }

    public Task<ServiceResult<WishlistItemDto>> AddToWishlistAsync(int userId, AddToWishlistRequest request)
    {
        var product = DataStore.Products.FirstOrDefault(p => p.Id == request.ProductId && p.IsActive);
        if (product is null)
            return Task.FromResult(ServiceResult<WishlistItemDto>.NotFound($"Product {request.ProductId} not found."));

        if (DataStore.WishlistItems.Any(w => w.UserId == userId && w.ProductId == request.ProductId))
            return Task.FromResult(ServiceResult<WishlistItemDto>.Failure("Product is already in your wishlist."));

        var item = new WishlistItem
        {
            Id = DataStore.NextWishlistId,
            UserId = userId,
            ProductId = request.ProductId,
            AddedAt = DateTime.UtcNow
        };

        DataStore.WishlistItems.Add(item);

        var dto = new WishlistItemDto
        {
            Id = item.Id,
            ProductId = product.Id,
            ProductName = product.Name,
            ProductImage = product.ImageUrl,
            Brand = product.Brand,
            Price = product.Price,
            DiscountPrice = product.DiscountPrice,
            InStock = product.Stock > 0,
            Rating = product.Rating,
            AddedAt = item.AddedAt
        };

        return Task.FromResult(ServiceResult<WishlistItemDto>.Success(dto, 201));
    }

    public Task<ServiceResult<bool>> RemoveFromWishlistAsync(int userId, int wishlistItemId)
    {
        var item = DataStore.WishlistItems.FirstOrDefault(w => w.Id == wishlistItemId && w.UserId == userId);
        if (item is null)
            return Task.FromResult(ServiceResult<bool>.NotFound("Wishlist item not found."));

        DataStore.WishlistItems.Remove(item);
        return Task.FromResult(ServiceResult<bool>.Success(true));
    }

    public Task<ServiceResult<bool>> ClearWishlistAsync(int userId)
    {
        var items = DataStore.WishlistItems.Where(w => w.UserId == userId).ToList();
        foreach (var item in items)
            DataStore.WishlistItems.Remove(item);

        return Task.FromResult(ServiceResult<bool>.Success(true));
    }

    public async Task<ServiceResult<bool>> MoveToCartAsync(int userId, int wishlistItemId)
    {
        var wishlistItem = DataStore.WishlistItems.FirstOrDefault(w => w.Id == wishlistItemId && w.UserId == userId);
        if (wishlistItem is null)
            return ServiceResult<bool>.NotFound("Wishlist item not found.");

        var addResult = await cartService.AddToCartAsync(userId, new AddToCartRequest
        {
            ProductId = wishlistItem.ProductId,
            Quantity = 1
        });

        if (!addResult.IsSuccess)
            return ServiceResult<bool>.Failure(addResult.ErrorMessage!);

        DataStore.WishlistItems.Remove(wishlistItem);
        return ServiceResult<bool>.Success(true);
    }
}
