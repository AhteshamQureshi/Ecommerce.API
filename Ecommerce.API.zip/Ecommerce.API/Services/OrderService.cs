using Ecommerce.API.Data;
using Ecommerce.API.DTOs.Order;
using Ecommerce.API.Models;
using Ecommerce.API.Services.Interfaces;

namespace Ecommerce.API.Services;

public class OrderService : IOrderService
{
    private static readonly string[] ValidStatuses =
        ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"];

    public Task<ServiceResult<List<OrderDto>>> GetUserOrdersAsync(int userId)
    {
        var orders = DataStore.Orders
            .Where(o => o.UserId == userId)
            .OrderByDescending(o => o.OrderDate)
            .Select(MapToDto)
            .ToList();

        return Task.FromResult(ServiceResult<List<OrderDto>>.Success(orders));
    }

    public Task<ServiceResult<OrderDto>> GetOrderByIdAsync(int orderId, int userId)
    {
        var order = DataStore.Orders.FirstOrDefault(o => o.Id == orderId && o.UserId == userId);
        if (order is null)
            return Task.FromResult(ServiceResult<OrderDto>.NotFound($"Order {orderId} not found."));

        return Task.FromResult(ServiceResult<OrderDto>.Success(MapToDto(order)));
    }

    public Task<ServiceResult<OrderDto>> PlaceOrderAsync(int userId, PlaceOrderRequest request)
    {
        var cartItems = DataStore.CartItems.Where(c => c.UserId == userId).ToList();
        if (!cartItems.Any())
            return Task.FromResult(ServiceResult<OrderDto>.Failure("Your cart is empty."));

        // Validate stock
        foreach (var cartItem in cartItems)
        {
            var product = DataStore.Products.FirstOrDefault(p => p.Id == cartItem.ProductId && p.IsActive);
            if (product is null)
                return Task.FromResult(ServiceResult<OrderDto>.Failure($"Product {cartItem.ProductId} is no longer available."));
            if (product.Stock < cartItem.Quantity)
                return Task.FromResult(ServiceResult<OrderDto>.Failure($"Insufficient stock for '{product.Name}'. Available: {product.Stock}."));
        }

        // Build order items & deduct stock
        var orderItems = new List<OrderItem>();
        decimal total = 0;
        int orderItemId = 1;

        foreach (var cartItem in cartItems)
        {
            var product = DataStore.Products.First(p => p.Id == cartItem.ProductId);
            var unitPrice = product.DiscountPrice ?? product.Price;
            total += unitPrice * cartItem.Quantity;
            product.Stock -= cartItem.Quantity; // Deduct stock

            orderItems.Add(new OrderItem
            {
                Id = orderItemId++,
                ProductId = product.Id,
                ProductName = product.Name,
                Quantity = cartItem.Quantity,
                UnitPrice = unitPrice
            });
        }

        var order = new Order
        {
            Id = DataStore.NextOrderId,
            UserId = userId,
            Items = orderItems,
            TotalAmount = total,
            ShippingAddress = request.ShippingAddress,
            PaymentMethod = request.PaymentMethod,
            PaymentStatus = "Paid", // Assume payment always succeeds in demo
            Status = "Processing",
            OrderDate = DateTime.UtcNow
        };

        DataStore.Orders.Add(order);

        // Clear cart
        foreach (var item in cartItems)
            DataStore.CartItems.Remove(item);

        return Task.FromResult(ServiceResult<OrderDto>.Success(MapToDto(order), 201));
    }

    public Task<ServiceResult<OrderDto>> UpdateOrderStatusAsync(int orderId, UpdateOrderStatusRequest request)
    {
        if (!ValidStatuses.Contains(request.Status))
            return Task.FromResult(ServiceResult<OrderDto>.Failure($"Invalid status. Valid values: {string.Join(", ", ValidStatuses)}."));

        var order = DataStore.Orders.FirstOrDefault(o => o.Id == orderId);
        if (order is null)
            return Task.FromResult(ServiceResult<OrderDto>.NotFound($"Order {orderId} not found."));

        order.Status = request.Status;
        if (request.Status == "Delivered")
            order.DeliveredAt = DateTime.UtcNow;

        return Task.FromResult(ServiceResult<OrderDto>.Success(MapToDto(order)));
    }

    public Task<ServiceResult<bool>> CancelOrderAsync(int orderId, int userId)
    {
        var order = DataStore.Orders.FirstOrDefault(o => o.Id == orderId && o.UserId == userId);
        if (order is null)
            return Task.FromResult(ServiceResult<bool>.NotFound($"Order {orderId} not found."));

        if (order.Status is "Shipped" or "Delivered")
            return Task.FromResult(ServiceResult<bool>.Failure($"Cannot cancel an order that is already {order.Status}."));

        // Restore stock
        foreach (var item in order.Items)
        {
            var product = DataStore.Products.FirstOrDefault(p => p.Id == item.ProductId);
            if (product is not null) product.Stock += item.Quantity;
        }

        order.Status = "Cancelled";
        return Task.FromResult(ServiceResult<bool>.Success(true));
    }

    public Task<ServiceResult<List<OrderDto>>> GetAllOrdersAsync()
    {
        var orders = DataStore.Orders
            .OrderByDescending(o => o.OrderDate)
            .Select(MapToDto)
            .ToList();

        return Task.FromResult(ServiceResult<List<OrderDto>>.Success(orders));
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private static OrderDto MapToDto(Order o) => new()
    {
        Id = o.Id,
        UserId = o.UserId,
        TotalAmount = o.TotalAmount,
        Status = o.Status,
        ShippingAddress = o.ShippingAddress,
        PaymentMethod = o.PaymentMethod,
        PaymentStatus = o.PaymentStatus,
        OrderDate = o.OrderDate,
        DeliveredAt = o.DeliveredAt,
        Items = o.Items.Select(i => new OrderItemDto
        {
            ProductId = i.ProductId,
            ProductName = i.ProductName,
            Quantity = i.Quantity,
            UnitPrice = i.UnitPrice,
            TotalPrice = i.TotalPrice
        }).ToList()
    };
}
