namespace Ecommerce.API.Services;

/// <summary>
/// Generic result wrapper to avoid throwing exceptions for business logic failures.
/// </summary>
public class ServiceResult<T>
{
    public bool IsSuccess { get; private set; }
    public T? Data { get; private set; }
    public string? ErrorMessage { get; private set; }
    public int StatusCode { get; private set; }

    private ServiceResult() { }

    public static ServiceResult<T> Success(T data, int statusCode = 200) =>
        new() { IsSuccess = true, Data = data, StatusCode = statusCode };

    public static ServiceResult<T> Failure(string message, int statusCode = 400) =>
        new() { IsSuccess = false, ErrorMessage = message, StatusCode = statusCode };

    public static ServiceResult<T> NotFound(string message = "Resource not found") =>
        Failure(message, 404);

    public static ServiceResult<T> Unauthorized(string message = "Unauthorized") =>
        Failure(message, 401);
}
