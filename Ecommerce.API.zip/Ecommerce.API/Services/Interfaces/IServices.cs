using Ecommerce.API.DTOs.Auth;
using Ecommerce.API.DTOs.Cart;
using Ecommerce.API.DTOs.Category;
using Ecommerce.API.DTOs.Order;
using Ecommerce.API.DTOs.Product;
using Ecommerce.API.DTOs.User;
using Ecommerce.API.DTOs.Wishlist;

namespace Ecommerce.API.Services.Interfaces;

public interface IAuthService
{
    Task<ServiceResult<AuthResponse>> LoginAsync(LoginRequest request);
    Task<ServiceResult<AuthResponse>> RegisterAsync(RegisterRequest request);
}

public interface IUserService
{
    Task<ServiceResult<List<UserDto>>> GetAllUsersAsync();
    Task<ServiceResult<UserDto>> GetUserByIdAsync(int id);
    Task<ServiceResult<UserDto>> UpdateUserAsync(int id, UpdateUserRequest request);
    Task<ServiceResult<bool>> ChangePasswordAsync(int id, ChangePasswordRequest request);
    Task<ServiceResult<bool>> DeleteUserAsync(int id);
}

public interface ICategoryService
{
    Task<ServiceResult<List<CategoryDto>>> GetAllCategoriesAsync();
    Task<ServiceResult<CategoryDto>> GetCategoryByIdAsync(int id);
    Task<ServiceResult<CategoryDto>> CreateCategoryAsync(CreateCategoryRequest request);
    Task<ServiceResult<CategoryDto>> UpdateCategoryAsync(int id, UpdateCategoryRequest request);
    Task<ServiceResult<bool>> DeleteCategoryAsync(int id);
}

public interface IProductService
{
    Task<ServiceResult<PagedResult<ProductDto>>> GetProductsAsync(ProductFilterRequest filter);
    Task<ServiceResult<ProductDto>> GetProductByIdAsync(int id);
    Task<ServiceResult<List<ProductDto>>> GetProductsByCategoryAsync(int categoryId);
    Task<ServiceResult<ProductDto>> CreateProductAsync(CreateProductRequest request);
    Task<ServiceResult<ProductDto>> UpdateProductAsync(int id, UpdateProductRequest request);
    Task<ServiceResult<bool>> DeleteProductAsync(int id);
}

public interface ICartService
{
    Task<ServiceResult<CartSummaryDto>> GetCartAsync(int userId);
    Task<ServiceResult<CartSummaryDto>> AddToCartAsync(int userId, AddToCartRequest request);
    Task<ServiceResult<CartSummaryDto>> UpdateCartItemAsync(int userId, int cartItemId, UpdateCartItemRequest request);
    Task<ServiceResult<CartSummaryDto>> RemoveFromCartAsync(int userId, int cartItemId);
    Task<ServiceResult<bool>> ClearCartAsync(int userId);
}

public interface IOrderService
{
    Task<ServiceResult<List<OrderDto>>> GetUserOrdersAsync(int userId);
    Task<ServiceResult<OrderDto>> GetOrderByIdAsync(int orderId, int userId);
    Task<ServiceResult<OrderDto>> PlaceOrderAsync(int userId, PlaceOrderRequest request);
    Task<ServiceResult<OrderDto>> UpdateOrderStatusAsync(int orderId, UpdateOrderStatusRequest request);
    Task<ServiceResult<bool>> CancelOrderAsync(int orderId, int userId);
    Task<ServiceResult<List<OrderDto>>> GetAllOrdersAsync(); // Admin
}

public interface IWishlistService
{
    Task<ServiceResult<List<WishlistItemDto>>> GetWishlistAsync(int userId);
    Task<ServiceResult<WishlistItemDto>> AddToWishlistAsync(int userId, AddToWishlistRequest request);
    Task<ServiceResult<bool>> RemoveFromWishlistAsync(int userId, int wishlistItemId);
    Task<ServiceResult<bool>> ClearWishlistAsync(int userId);
    Task<ServiceResult<bool>> MoveToCartAsync(int userId, int wishlistItemId);
}
