using Ecommerce.API.Data;
using Ecommerce.API.DTOs.Product;
using Ecommerce.API.Models;
using Ecommerce.API.Services.Interfaces;

namespace Ecommerce.API.Services;

public class ProductService : IProductService
{
    public Task<ServiceResult<PagedResult<ProductDto>>> GetProductsAsync(ProductFilterRequest filter)
    {
        var query = DataStore.Products.Where(p => p.IsActive).AsQueryable();

        // Filters
        if (filter.CategoryId.HasValue)
            query = query.Where(p => p.CategoryId == filter.CategoryId.Value);

        if (!string.IsNullOrWhiteSpace(filter.Brand))
            query = query.Where(p => p.Brand.Equals(filter.Brand, StringComparison.OrdinalIgnoreCase));

        if (filter.MinPrice.HasValue)
            query = query.Where(p => (p.DiscountPrice ?? p.Price) >= filter.MinPrice.Value);

        if (filter.MaxPrice.HasValue)
            query = query.Where(p => (p.DiscountPrice ?? p.Price) <= filter.MaxPrice.Value);

        if (!string.IsNullOrWhiteSpace(filter.Search))
            query = query.Where(p =>
                p.Name.Contains(filter.Search, StringComparison.OrdinalIgnoreCase) ||
                p.Description.Contains(filter.Search, StringComparison.OrdinalIgnoreCase) ||
                p.Brand.Contains(filter.Search, StringComparison.OrdinalIgnoreCase));

        // Sorting
        query = (filter.SortBy.ToLower(), filter.SortOrder.ToLower()) switch
        {
            ("price", "desc") => query.OrderByDescending(p => p.DiscountPrice ?? p.Price),
            ("price", _)      => query.OrderBy(p => p.DiscountPrice ?? p.Price),
            ("rating", "desc") => query.OrderByDescending(p => p.Rating),
            ("rating", _)     => query.OrderBy(p => p.Rating),
            (_, "desc")       => query.OrderByDescending(p => p.Name),
            _                 => query.OrderBy(p => p.Name)
        };

        var total = query.Count();

        var items = query
            .Skip((filter.Page - 1) * filter.PageSize)
            .Take(filter.PageSize)
            .Select(MapToDto)
            .ToList();

        var result = new PagedResult<ProductDto>
        {
            Items = items,
            TotalCount = total,
            Page = filter.Page,
            PageSize = filter.PageSize
        };

        return Task.FromResult(ServiceResult<PagedResult<ProductDto>>.Success(result));
    }

    public Task<ServiceResult<ProductDto>> GetProductByIdAsync(int id)
    {
        var product = DataStore.Products.FirstOrDefault(p => p.Id == id && p.IsActive);
        if (product is null)
            return Task.FromResult(ServiceResult<ProductDto>.NotFound($"Product {id} not found."));

        return Task.FromResult(ServiceResult<ProductDto>.Success(MapToDto(product)));
    }

    public Task<ServiceResult<List<ProductDto>>> GetProductsByCategoryAsync(int categoryId)
    {
        var category = DataStore.Categories.FirstOrDefault(c => c.Id == categoryId);
        if (category is null)
            return Task.FromResult(ServiceResult<List<ProductDto>>.NotFound($"Category {categoryId} not found."));

        var products = DataStore.Products
            .Where(p => p.CategoryId == categoryId && p.IsActive)
            .Select(MapToDto)
            .ToList();

        return Task.FromResult(ServiceResult<List<ProductDto>>.Success(products));
    }

    public Task<ServiceResult<ProductDto>> CreateProductAsync(CreateProductRequest request)
    {
        if (!DataStore.Categories.Any(c => c.Id == request.CategoryId && c.IsActive))
            return Task.FromResult(ServiceResult<ProductDto>.Failure($"Category {request.CategoryId} does not exist."));

        var product = new Product
        {
            Id = DataStore.NextProductId,
            Name = request.Name,
            Description = request.Description,
            Price = request.Price,
            DiscountPrice = request.DiscountPrice,
            Stock = request.Stock,
            CategoryId = request.CategoryId,
            Brand = request.Brand,
            ImageUrl = request.ImageUrl,
            CreatedAt = DateTime.UtcNow
        };

        DataStore.Products.Add(product);
        return Task.FromResult(ServiceResult<ProductDto>.Success(MapToDto(product), 201));
    }

    public Task<ServiceResult<ProductDto>> UpdateProductAsync(int id, UpdateProductRequest request)
    {
        var product = DataStore.Products.FirstOrDefault(p => p.Id == id);
        if (product is null)
            return Task.FromResult(ServiceResult<ProductDto>.NotFound($"Product {id} not found."));

        if (!DataStore.Categories.Any(c => c.Id == request.CategoryId && c.IsActive))
            return Task.FromResult(ServiceResult<ProductDto>.Failure($"Category {request.CategoryId} does not exist."));

        product.Name = request.Name;
        product.Description = request.Description;
        product.Price = request.Price;
        product.DiscountPrice = request.DiscountPrice;
        product.Stock = request.Stock;
        product.CategoryId = request.CategoryId;
        product.Brand = request.Brand;
        product.ImageUrl = request.ImageUrl;
        product.IsActive = request.IsActive;

        return Task.FromResult(ServiceResult<ProductDto>.Success(MapToDto(product)));
    }

    public Task<ServiceResult<bool>> DeleteProductAsync(int id)
    {
        var product = DataStore.Products.FirstOrDefault(p => p.Id == id);
        if (product is null)
            return Task.FromResult(ServiceResult<bool>.NotFound($"Product {id} not found."));

        product.IsActive = false;
        return Task.FromResult(ServiceResult<bool>.Success(true));
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private static ProductDto MapToDto(Product p)
    {
        var category = DataStore.Categories.FirstOrDefault(c => c.Id == p.CategoryId);
        return new ProductDto
        {
            Id = p.Id,
            Name = p.Name,
            Description = p.Description,
            Price = p.Price,
            DiscountPrice = p.DiscountPrice,
            Stock = p.Stock,
            CategoryId = p.CategoryId,
            CategoryName = category?.Name ?? "Unknown",
            Brand = p.Brand,
            ImageUrl = p.ImageUrl,
            Rating = p.Rating,
            ReviewCount = p.ReviewCount,
            IsActive = p.IsActive,
            CreatedAt = p.CreatedAt
        };
    }
}
