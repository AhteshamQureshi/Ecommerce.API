using Ecommerce.API.Data;
using Ecommerce.API.DTOs.Cart;
using Ecommerce.API.Models;
using Ecommerce.API.Services.Interfaces;

namespace Ecommerce.API.Services;

public class CartService : ICartService
{
    public Task<ServiceResult<CartSummaryDto>> GetCartAsync(int userId)
    {
        var summary = BuildCartSummary(userId);
        return Task.FromResult(ServiceResult<CartSummaryDto>.Success(summary));
    }

    public Task<ServiceResult<CartSummaryDto>> AddToCartAsync(int userId, AddToCartRequest request)
    {
        var product = DataStore.Products.FirstOrDefault(p => p.Id == request.ProductId && p.IsActive);
        if (product is null)
            return Task.FromResult(ServiceResult<CartSummaryDto>.NotFound($"Product {request.ProductId} not found."));

        if (product.Stock < request.Quantity)
            return Task.FromResult(ServiceResult<CartSummaryDto>.Failure($"Only {product.Stock} units in stock."));

        var existing = DataStore.CartItems.FirstOrDefault(c => c.UserId == userId && c.ProductId == request.ProductId);
        if (existing is not null)
        {
            var newQty = existing.Quantity + request.Quantity;
            if (newQty > product.Stock)
                return Task.FromResult(ServiceResult<CartSummaryDto>.Failure($"Cannot add more than {product.Stock} units."));
            existing.Quantity = newQty;
        }
        else
        {
            DataStore.CartItems.Add(new CartItem
            {
                Id = DataStore.NextCartItemId,
                UserId = userId,
                ProductId = request.ProductId,
                Quantity = request.Quantity,
                AddedAt = DateTime.UtcNow
            });
        }

        return Task.FromResult(ServiceResult<CartSummaryDto>.Success(BuildCartSummary(userId)));
    }

    public Task<ServiceResult<CartSummaryDto>> UpdateCartItemAsync(int userId, int cartItemId, UpdateCartItemRequest request)
    {
        var item = DataStore.CartItems.FirstOrDefault(c => c.Id == cartItemId && c.UserId == userId);
        if (item is null)
            return Task.FromResult(ServiceResult<CartSummaryDto>.NotFound("Cart item not found."));

        if (request.Quantity <= 0)
        {
            DataStore.CartItems.Remove(item);
        }
        else
        {
            var product = DataStore.Products.FirstOrDefault(p => p.Id == item.ProductId);
            if (product is not null && request.Quantity > product.Stock)
                return Task.FromResult(ServiceResult<CartSummaryDto>.Failure($"Only {product.Stock} units available."));

            item.Quantity = request.Quantity;
        }

        return Task.FromResult(ServiceResult<CartSummaryDto>.Success(BuildCartSummary(userId)));
    }

    public Task<ServiceResult<CartSummaryDto>> RemoveFromCartAsync(int userId, int cartItemId)
    {
        var item = DataStore.CartItems.FirstOrDefault(c => c.Id == cartItemId && c.UserId == userId);
        if (item is null)
            return Task.FromResult(ServiceResult<CartSummaryDto>.NotFound("Cart item not found."));

        DataStore.CartItems.Remove(item);
        return Task.FromResult(ServiceResult<CartSummaryDto>.Success(BuildCartSummary(userId)));
    }

    public Task<ServiceResult<bool>> ClearCartAsync(int userId)
    {
        var items = DataStore.CartItems.Where(c => c.UserId == userId).ToList();
        foreach (var item in items)
            DataStore.CartItems.Remove(item);

        return Task.FromResult(ServiceResult<bool>.Success(true));
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private static CartSummaryDto BuildCartSummary(int userId)
    {
        var items = DataStore.CartItems
            .Where(c => c.UserId == userId)
            .Select(c =>
            {
                var product = DataStore.Products.FirstOrDefault(p => p.Id == c.ProductId);
                return product is null ? null : new CartItemDto
                {
                    Id = c.Id,
                    ProductId = product.Id,
                    ProductName = product.Name,
                    ProductImage = product.ImageUrl,
                    Brand = product.Brand,
                    UnitPrice = product.DiscountPrice ?? product.Price,
                    Quantity = c.Quantity,
                    AvailableStock = product.Stock
                };
            })
            .Where(i => i is not null)
            .Cast<CartItemDto>()
            .ToList();

        return new CartSummaryDto { Items = items };
    }
}
