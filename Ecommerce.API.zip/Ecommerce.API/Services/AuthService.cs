using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Ecommerce.API.Data;
using Ecommerce.API.DTOs.Auth;
using Ecommerce.API.Models;
using Ecommerce.API.Services.Interfaces;
using Microsoft.IdentityModel.Tokens;

namespace Ecommerce.API.Services;

public class AuthService(IConfiguration configuration) : IAuthService
{
    public Task<ServiceResult<AuthResponse>> LoginAsync(LoginRequest request)
    {
        var user = DataStore.Users.FirstOrDefault(u =>
            u.Email.Equals(request.Email, StringComparison.OrdinalIgnoreCase) && u.IsActive);

        if (user is null || !DataStore.VerifyPassword(request.Password, user.PasswordHash))
            return Task.FromResult(ServiceResult<AuthResponse>.Unauthorized("Invalid email or password."));

        var response = BuildAuthResponse(user);
        return Task.FromResult(ServiceResult<AuthResponse>.Success(response));
    }

    public Task<ServiceResult<AuthResponse>> RegisterAsync(RegisterRequest request)
    {
        if (DataStore.Users.Any(u => u.Email.Equals(request.Email, StringComparison.OrdinalIgnoreCase)))
            return Task.FromResult(ServiceResult<AuthResponse>.Failure("Email is already registered."));

        var user = new User
        {
            Id = DataStore.NextUserId,
            FirstName = request.FirstName,
            LastName = request.LastName,
            Email = request.Email,
            PasswordHash = DataStore.HashPassword(request.Password),
            Phone = request.Phone,
            Address = request.Address,
            Role = "Customer",
            CreatedAt = DateTime.UtcNow
        };

        DataStore.Users.Add(user);

        var response = BuildAuthResponse(user);
        return Task.FromResult(ServiceResult<AuthResponse>.Success(response, 201));
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private AuthResponse BuildAuthResponse(User user)
    {
        var expiry = DateTime.UtcNow.AddHours(24);
        var token = GenerateJwtToken(user, expiry);

        return new AuthResponse
        {
            Token = token,
            ExpiresAt = expiry,
            User = new UserInfo
            {
                Id = user.Id,
                FullName = $"{user.FirstName} {user.LastName}",
                Email = user.Email,
                Role = user.Role
            }
        };
    }

    private string GenerateJwtToken(User user, DateTime expiry)
    {
        var key = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(configuration["Jwt:Key"] ?? "SuperSecretKeyForDevOnly_ChangeInProd!"));

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),
            new Claim(ClaimTypes.Role, user.Role),
        };

        var token = new JwtSecurityToken(
            issuer: configuration["Jwt:Issuer"] ?? "Ecommerce.API",
            audience: configuration["Jwt:Audience"] ?? "Ecommerce.Client",
            claims: claims,
            expires: expiry,
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
