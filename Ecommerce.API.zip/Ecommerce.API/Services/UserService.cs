using Ecommerce.API.Data;
using Ecommerce.API.DTOs.User;
using Ecommerce.API.Services.Interfaces;

namespace Ecommerce.API.Services;

public class UserService : IUserService
{
    public Task<ServiceResult<List<UserDto>>> GetAllUsersAsync()
    {
        var users = DataStore.Users
            .Where(u => u.IsActive)
            .Select(MapToDto)
            .ToList();

        return Task.FromResult(ServiceResult<List<UserDto>>.Success(users));
    }

    public Task<ServiceResult<UserDto>> GetUserByIdAsync(int id)
    {
        var user = DataStore.Users.FirstOrDefault(u => u.Id == id && u.IsActive);
        if (user is null)
            return Task.FromResult(ServiceResult<UserDto>.NotFound($"User {id} not found."));

        return Task.FromResult(ServiceResult<UserDto>.Success(MapToDto(user)));
    }

    public Task<ServiceResult<UserDto>> UpdateUserAsync(int id, UpdateUserRequest request)
    {
        var user = DataStore.Users.FirstOrDefault(u => u.Id == id && u.IsActive);
        if (user is null)
            return Task.FromResult(ServiceResult<UserDto>.NotFound($"User {id} not found."));

        user.FirstName = request.FirstName;
        user.LastName = request.LastName;
        user.Phone = request.Phone;
        user.Address = request.Address;

        return Task.FromResult(ServiceResult<UserDto>.Success(MapToDto(user)));
    }

    public Task<ServiceResult<bool>> ChangePasswordAsync(int id, ChangePasswordRequest request)
    {
        var user = DataStore.Users.FirstOrDefault(u => u.Id == id && u.IsActive);
        if (user is null)
            return Task.FromResult(ServiceResult<bool>.NotFound($"User {id} not found."));

        if (!DataStore.VerifyPassword(request.CurrentPassword, user.PasswordHash))
            return Task.FromResult(ServiceResult<bool>.Failure("Current password is incorrect."));

        user.PasswordHash = DataStore.HashPassword(request.NewPassword);
        return Task.FromResult(ServiceResult<bool>.Success(true));
    }

    public Task<ServiceResult<bool>> DeleteUserAsync(int id)
    {
        var user = DataStore.Users.FirstOrDefault(u => u.Id == id);
        if (user is null)
            return Task.FromResult(ServiceResult<bool>.NotFound($"User {id} not found."));

        user.IsActive = false; // Soft delete
        return Task.FromResult(ServiceResult<bool>.Success(true));
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private static UserDto MapToDto(Models.User u) => new()
    {
        Id = u.Id,
        FirstName = u.FirstName,
        LastName = u.LastName,
        Email = u.Email,
        Role = u.Role,
        Phone = u.Phone,
        Address = u.Address,
        IsActive = u.IsActive,
        CreatedAt = u.CreatedAt
    };
}
