using Ecommerce.API.DTOs.Order;
using Ecommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.API.Controllers;

/// <summary>Order management — all endpoints require authentication.</summary>
[Authorize]
public class OrdersController(IOrderService orderService) : BaseController
{
    /// <summary>Get all orders for the current user.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<OrderDto>), 200)]
    public async Task<IActionResult> GetMyOrders()
    {
        var result = await orderService.GetUserOrdersAsync(GetCurrentUserId());
        return ToActionResult(result);
    }

    /// <summary>[Admin] Get all orders across all users.</summary>
    [HttpGet("all")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(List<OrderDto>), 200)]
    public async Task<IActionResult> GetAll()
    {
        var result = await orderService.GetAllOrdersAsync();
        return ToActionResult(result);
    }

    /// <summary>Get a specific order by ID (must belong to the current user).</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(OrderDto), 200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> GetById(int id)
    {
        var result = await orderService.GetOrderByIdAsync(id, GetCurrentUserId());
        return ToActionResult(result);
    }

    /// <summary>
    /// Place an order using the current cart contents.
    /// Validates stock, deducts inventory, clears the cart, and returns the created order.
    /// </summary>
    [HttpPost]
    [ProducesResponseType(typeof(OrderDto), 201)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> PlaceOrder([FromBody] PlaceOrderRequest request)
    {
        var result = await orderService.PlaceOrderAsync(GetCurrentUserId(), request);
        return ToActionResult(result);
    }

    /// <summary>[Admin] Update an order's status (e.g. mark as Shipped or Delivered).</summary>
    [HttpPatch("{id:int}/status")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(OrderDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateOrderStatusRequest request)
    {
        var result = await orderService.UpdateOrderStatusAsync(id, request);
        return ToActionResult(result);
    }

    /// <summary>Cancel an order (only Pending or Processing orders can be cancelled).</summary>
    [HttpPost("{id:int}/cancel")]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Cancel(int id)
    {
        var result = await orderService.CancelOrderAsync(id, GetCurrentUserId());
        return ToActionResult(result);
    }
}
