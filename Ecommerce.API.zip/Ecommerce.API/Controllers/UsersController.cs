using Ecommerce.API.DTOs.User;
using Ecommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.API.Controllers;

/// <summary>Manage user accounts. Admins can see all users; customers can only manage their own profile.</summary>
[Authorize]
public class UsersController(IUserService userService) : BaseController
{
    /// <summary>[Admin] Get all users.</summary>
    [HttpGet]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(List<UserDto>), 200)]
    public async Task<IActionResult> GetAll()
    {
        var result = await userService.GetAllUsersAsync();
        return ToActionResult(result);
    }

    /// <summary>Get a user by ID. Customers can only access their own profile.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(UserDto), 200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> GetById(int id)
    {
        // Customers can only view their own profile
        if (!User.IsInRole("Admin") && GetCurrentUserId() != id)
            return Forbid();

        var result = await userService.GetUserByIdAsync(id);
        return ToActionResult(result);
    }

    /// <summary>Get the currently authenticated user's profile.</summary>
    [HttpGet("me")]
    [ProducesResponseType(typeof(UserDto), 200)]
    public async Task<IActionResult> GetMe()
    {
        var result = await userService.GetUserByIdAsync(GetCurrentUserId());
        return ToActionResult(result);
    }

    /// <summary>Update a user's profile information.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(UserDto), 200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateUserRequest request)
    {
        if (!User.IsInRole("Admin") && GetCurrentUserId() != id)
            return Forbid();

        var result = await userService.UpdateUserAsync(id, request);
        return ToActionResult(result);
    }

    /// <summary>Change the password for a user account.</summary>
    [HttpPost("{id:int}/change-password")]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> ChangePassword(int id, [FromBody] ChangePasswordRequest request)
    {
        if (GetCurrentUserId() != id)
            return Forbid();

        var result = await userService.ChangePasswordAsync(id, request);
        return ToActionResult(result);
    }

    /// <summary>[Admin] Soft-delete (deactivate) a user account.</summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await userService.DeleteUserAsync(id);
        return ToActionResult(result);
    }
}
