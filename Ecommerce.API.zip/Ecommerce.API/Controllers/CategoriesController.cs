using Ecommerce.API.DTOs.Category;
using Ecommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.API.Controllers;

/// <summary>Product categories — browsing is public, management requires Admin role.</summary>
public class CategoriesController(ICategoryService categoryService) : BaseController
{
    /// <summary>Get all active categories (public).</summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<CategoryDto>), 200)]
    public async Task<IActionResult> GetAll()
    {
        var result = await categoryService.GetAllCategoriesAsync();
        return ToActionResult(result);
    }

    /// <summary>Get a single category by ID (public).</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(CategoryDto), 200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> GetById(int id)
    {
        var result = await categoryService.GetCategoryByIdAsync(id);
        return ToActionResult(result);
    }

    /// <summary>[Admin] Create a new category.</summary>
    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(CategoryDto), 201)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> Create([FromBody] CreateCategoryRequest request)
    {
        var result = await categoryService.CreateCategoryAsync(request);
        return ToActionResult(result);
    }

    /// <summary>[Admin] Update an existing category.</summary>
    [HttpPut("{id:int}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(CategoryDto), 200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateCategoryRequest request)
    {
        var result = await categoryService.UpdateCategoryAsync(id, request);
        return ToActionResult(result);
    }

    /// <summary>[Admin] Soft-delete a category (fails if it has active products).</summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await categoryService.DeleteCategoryAsync(id);
        return ToActionResult(result);
    }
}
