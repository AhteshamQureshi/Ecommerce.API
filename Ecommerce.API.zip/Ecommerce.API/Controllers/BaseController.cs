using System.Security.Claims;
using Ecommerce.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public abstract class BaseController : ControllerBase
{
    /// <summary>Converts a ServiceResult into the appropriate IActionResult.</summary>
    protected IActionResult ToActionResult<T>(ServiceResult<T> result)
    {
        if (!result.IsSuccess)
        {
            return result.StatusCode switch
            {
                404 => NotFound(new { message = result.ErrorMessage }),
                401 => Unauthorized(new { message = result.ErrorMessage }),
                _   => BadRequest(new { message = result.ErrorMessage })
            };
        }

        return result.StatusCode == 201
            ? StatusCode(201, result.Data)
            : Ok(result.Data);
    }

    /// <summary>Gets the authenticated user's ID from the JWT claims.</summary>
    protected int GetCurrentUserId()
    {
        var claim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return int.TryParse(claim, out var id) ? id : 0;
    }
}
