using Ecommerce.API.DTOs.Wishlist;
using Ecommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.API.Controllers;

/// <summary>Wishlist management — all endpoints require authentication.</summary>
[Authorize]
public class WishlistController(IWishlistService wishlistService) : BaseController
{
    /// <summary>Get all wishlist items for the current user.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<WishlistItemDto>), 200)]
    public async Task<IActionResult> GetWishlist()
    {
        var result = await wishlistService.GetWishlistAsync(GetCurrentUserId());
        return ToActionResult(result);
    }

    /// <summary>Add a product to the wishlist.</summary>
    [HttpPost("items")]
    [ProducesResponseType(typeof(WishlistItemDto), 201)]
    [ProducesResponseType(400)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> AddItem([FromBody] AddToWishlistRequest request)
    {
        var result = await wishlistService.AddToWishlistAsync(GetCurrentUserId(), request);
        return ToActionResult(result);
    }

    /// <summary>Remove a specific item from the wishlist.</summary>
    [HttpDelete("items/{wishlistItemId:int}")]
    [ProducesResponseType(200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> RemoveItem(int wishlistItemId)
    {
        var result = await wishlistService.RemoveFromWishlistAsync(GetCurrentUserId(), wishlistItemId);
        return ToActionResult(result);
    }

    /// <summary>Clear all items from the wishlist.</summary>
    [HttpDelete]
    [ProducesResponseType(200)]
    public async Task<IActionResult> ClearWishlist()
    {
        var result = await wishlistService.ClearWishlistAsync(GetCurrentUserId());
        return ToActionResult(result);
    }

    /// <summary>Move a wishlist item to the cart and remove it from the wishlist.</summary>
    [HttpPost("items/{wishlistItemId:int}/move-to-cart")]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> MoveToCart(int wishlistItemId)
    {
        var result = await wishlistService.MoveToCartAsync(GetCurrentUserId(), wishlistItemId);
        return ToActionResult(result);
    }
}
