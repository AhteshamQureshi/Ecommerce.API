using Ecommerce.API.DTOs.Product;
using Ecommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.API.Controllers;

/// <summary>Product catalog — browsing is public, management requires Admin role.</summary>
public class ProductsController(IProductService productService) : BaseController
{
    /// <summary>
    /// Get a paginated, filtered list of products (public).
    /// Supports filtering by category, brand, price range, keyword search, and sorting.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<ProductDto>), 200)]
    public async Task<IActionResult> GetAll([FromQuery] ProductFilterRequest filter)
    {
        var result = await productService.GetProductsAsync(filter);
        return ToActionResult(result);
    }

    /// <summary>Get a single product by ID (public).</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ProductDto), 200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> GetById(int id)
    {
        var result = await productService.GetProductByIdAsync(id);
        return ToActionResult(result);
    }

    /// <summary>Get all products in a specific category (public).</summary>
    [HttpGet("category/{categoryId:int}")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> GetByCategory(int categoryId)
    {
        var result = await productService.GetProductsByCategoryAsync(categoryId);
        return ToActionResult(result);
    }

    /// <summary>[Admin] Create a new product.</summary>
    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(ProductDto), 201)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> Create([FromBody] CreateProductRequest request)
    {
        var result = await productService.CreateProductAsync(request);
        return ToActionResult(result);
    }

    /// <summary>[Admin] Update an existing product.</summary>
    [HttpPut("{id:int}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(ProductDto), 200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateProductRequest request)
    {
        var result = await productService.UpdateProductAsync(id, request);
        return ToActionResult(result);
    }

    /// <summary>[Admin] Soft-delete a product.</summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await productService.DeleteProductAsync(id);
        return ToActionResult(result);
    }
}
