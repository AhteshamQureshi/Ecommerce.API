using Ecommerce.API.DTOs.Cart;
using Ecommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.API.Controllers;

/// <summary>Shopping cart — all endpoints require authentication.</summary>
[Authorize]
public class CartController(ICartService cartService) : BaseController
{
    /// <summary>Get the current user's cart with totals and shipping calculation.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(CartSummaryDto), 200)]
    public async Task<IActionResult> GetCart()
    {
        var result = await cartService.GetCartAsync(GetCurrentUserId());
        return ToActionResult(result);
    }

    /// <summary>Add a product to the cart. If already present, increases quantity.</summary>
    [HttpPost("items")]
    [ProducesResponseType(typeof(CartSummaryDto), 200)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> AddItem([FromBody] AddToCartRequest request)
    {
        var result = await cartService.AddToCartAsync(GetCurrentUserId(), request);
        return ToActionResult(result);
    }

    /// <summary>Update the quantity of a cart item. Set quantity to 0 to remove it.</summary>
    [HttpPut("items/{cartItemId:int}")]
    [ProducesResponseType(typeof(CartSummaryDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> UpdateItem(int cartItemId, [FromBody] UpdateCartItemRequest request)
    {
        var result = await cartService.UpdateCartItemAsync(GetCurrentUserId(), cartItemId, request);
        return ToActionResult(result);
    }

    /// <summary>Remove a specific item from the cart.</summary>
    [HttpDelete("items/{cartItemId:int}")]
    [ProducesResponseType(typeof(CartSummaryDto), 200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> RemoveItem(int cartItemId)
    {
        var result = await cartService.RemoveFromCartAsync(GetCurrentUserId(), cartItemId);
        return ToActionResult(result);
    }

    /// <summary>Remove all items from the cart.</summary>
    [HttpDelete]
    [ProducesResponseType(200)]
    public async Task<IActionResult> ClearCart()
    {
        var result = await cartService.ClearCartAsync(GetCurrentUserId());
        return ToActionResult(result);
    }
}
