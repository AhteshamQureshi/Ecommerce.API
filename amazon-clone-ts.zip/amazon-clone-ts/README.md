# Amazon Clone — React + Vite + MUI v5 + TypeScript

## 🚀 Getting Started

```bash
npm install
npm run dev
```

Open http://localhost:5173

## 📁 Project Structure

```
src/
├── components/
│   ├── Header.tsx       # Sticky AppBar with search + cart badge
│   ├── Hero.tsx         # Banner with gradient + discount badge
│   ├── ProductGrid.tsx  # MUI Grid layout
│   ├── ProductCard.tsx  # Card with Rating, Chip, Button
│   ├── CartDrawer.tsx   # MUI Drawer slide-in cart
│   └── Footer.tsx       # Four-column footer
├── data/
│   └── products.ts      # 8 typed sample products
├── theme/
│   └── index.ts         # MUI custom theme (palette, typography)
├── types/
│   └── index.ts         # Product & CartItem interfaces
├── App.tsx              # Root component + state
└── main.tsx             # Entry point
```

## 🛠 Tech Stack
- React 18
- TypeScript
- Vite
- MUI v5 (Material UI)
- @mui/icons-material
- @emotion/react + @emotion/styled
