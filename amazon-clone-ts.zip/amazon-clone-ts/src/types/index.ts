export interface Product {
  id: number;
  title: string;
  price: number;
  originalPrice: number;
  rating: number;
  reviews: number;
  image: string;
  badge: string | null;
  category: string;
}

export interface CartItem extends Product {
  qty: number;
}
