import { Box, Typography, Grid, Link } from "@mui/material";
import ProductCard from "./ProductCard";
import type { Product } from "../types";

interface ProductGridProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
}

export default function ProductGrid({ products, onAddToCart }: ProductGridProps) {
  return (
    <Box sx={{ maxWidth: 1500, mx: "auto", px: 2, py: 3 }}>
      <Box sx={{ display: "flex", alignItems: "baseline", gap: 2, mb: 2.5, flexWrap: "wrap" }}>
        <Typography variant="h5" sx={{ fontWeight: 700, color: "text.primary" }}>Best Sellers</Typography>
        <Typography variant="body2" sx={{ color: "text.secondary" }}>Our most popular products based on sales</Typography>
        <Link href="#" underline="hover" sx={{ ml: "auto", fontSize: 13, color: "info.main", "&:hover": { color: "#c45500" } }}>
          See all best sellers →
        </Link>
      </Box>
      <Grid container spacing={2}>
        {products.map((product) => (
          <Grid key={product.id} size={{ xs: 12, sm: 6, md: 4, lg: 3 }}>
            <ProductCard product={product} onAddToCart={onAddToCart} />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
