import {
  Drawer, Box, Typography, IconButton, List, ListItem,
  Avatar, Button, Divider, Chip,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import DeleteIcon from "@mui/icons-material/Delete";
import type { CartItem } from "../types";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onRemove: (productId: number) => void;
}

export default function CartDrawer({ isOpen, onClose, cartItems, onRemove }: CartDrawerProps) {
  const total = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);
  const totalQty = cartItems.reduce((sum, item) => sum + item.qty, 0);

  return (
    <Drawer anchor="right" open={isOpen} onClose={onClose}
      slotProps={{ paper: { sx: { width: { xs: "95vw", sm: 420 }, display: "flex", flexDirection: "column" } } }}>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", px: 2.5, py: 2, borderBottom: "1px solid", borderColor: "divider" }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Typography variant="h6" sx={{ fontWeight: 700 }}>Shopping Cart</Typography>
          {cartItems.length > 0 && (
            <Chip label={totalQty} size="small" sx={{ bgcolor: "secondary.main", color: "primary.main", fontWeight: 800, height: 22, fontSize: 12 }} />
          )}
        </Box>
        <IconButton onClick={onClose} size="small" sx={{ "&:hover": { bgcolor: "#f3f3f3" } }}>
          <CloseIcon />
        </IconButton>
      </Box>

      {/* Body */}
      <Box sx={{ flex: 1, overflowY: "auto", px: 2.5, py: 2 }}>
        {cartItems.length === 0 ? (
          <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 280, gap: 1.5, textAlign: "center" }}>
            <ShoppingCartOutlinedIcon sx={{ fontSize: 64, color: "#ddd" }} />
            <Typography variant="h6" sx={{ fontWeight: 700 }}>Your cart is empty</Typography>
            <Typography variant="body2" sx={{ color: "text.secondary" }}>Add items to get started</Typography>
            <Button variant="contained" onClick={onClose}
              sx={{ mt: 1, bgcolor: "#FFD814", color: "primary.main", fontWeight: 700, "&:hover": { bgcolor: "#F7CA00" } }}>
              Continue Shopping
            </Button>
          </Box>
        ) : (
          <List disablePadding>
            {cartItems.map((item, idx) => (
              <Box key={item.id}>
                <ListItem disablePadding sx={{ py: 1.5, alignItems: "flex-start", gap: 1.5 }}>
                  <Avatar src={item.image} alt={item.title} variant="rounded"
                    sx={{ width: 72, height: 72, border: "1px solid #e8e8e8", flexShrink: 0 }} />
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography variant="body2" sx={{ fontWeight: 500, mb: 0.5, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                      {item.title}
                    </Typography>
                    <Typography variant="caption" sx={{ color: "text.secondary" }}>
                      ${item.price.toFixed(2)} × {item.qty}
                    </Typography>
                    <Box>
                      <Button size="small" startIcon={<DeleteIcon fontSize="small" />} onClick={() => onRemove(item.id)}
                        sx={{ color: "error.main", p: 0, fontSize: 12, mt: 0.5, minWidth: 0, "&:hover": { bgcolor: "transparent", textDecoration: "underline" } }}>
                        Remove
                      </Button>
                    </Box>
                  </Box>
                  <Typography variant="body2" sx={{ fontWeight: 700, flexShrink: 0 }}>
                    ${(item.price * item.qty).toFixed(2)}
                  </Typography>
                </ListItem>
                {idx < cartItems.length - 1 && <Divider />}
              </Box>
            ))}
          </List>
        )}
      </Box>

      {/* Footer */}
      {cartItems.length > 0 && (
        <Box sx={{ borderTop: "1px solid", borderColor: "divider", p: 2.5 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
            <Typography variant="body1">Subtotal ({totalQty} {totalQty === 1 ? "item" : "items"})</Typography>
            <Typography variant="h6" sx={{ fontWeight: 700 }}>${total.toFixed(2)}</Typography>
          </Box>
          <Button fullWidth variant="contained" size="large"
            sx={{ bgcolor: "#FFD814", color: "primary.main", fontWeight: 700, fontSize: 15, py: 1.2, "&:hover": { bgcolor: "#F7CA00" } }}>
            Proceed to Checkout
          </Button>
          <Typography variant="caption" sx={{ display: "block", textAlign: "center", color: "text.secondary", mt: 1.5 }}>
            Taxes calculated at checkout · Free shipping over $25
          </Typography>
        </Box>
      )}
    </Drawer>
  );
}
