import { useState } from "react";
import {
  Card,
  CardMedia,
  CardContent,
  CardActions,
  Typography,
  Button,
  Box,
  Chip,
  Rating,
} from "@mui/material";
import CheckIcon from "@mui/icons-material/Check";
import AddShoppingCartIcon from "@mui/icons-material/AddShoppingCart";
import type { Product } from "../types";

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const [added, setAdded] = useState<boolean>(false);

  const discount = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  const badgeColor = (badge: string): "warning" | "error" | "info" => {
    if (badge === "Best Seller") return "warning";
    if (badge === "Deal" || badge === "Limited Deal") return "error";
    return "info";
  };

  function handleAdd(): void {
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  }

  return (
    <Card sx={{ display: "flex", flexDirection: "column", height: "100%", position: "relative", border: "1px solid #e8e8e8" }}>
      {/* Badge */}
      {product.badge && (
        <Chip
          label={product.badge}
          color={badgeColor(product.badge)}
          size="small"
          sx={{
            position: "absolute",
            top: 10,
            left: 10,
            zIndex: 2,
            fontSize: 10,
            fontWeight: 800,
            letterSpacing: 0.5,
            height: 22,
          }}
        />
      )}

      {/* Image */}
      <Box sx={{ bgcolor: "#f8f8f8", overflow: "hidden", aspectRatio: "1" }}>
        <CardMedia
          component="img"
          image={product.image}
          alt={product.title}
          sx={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            transition: "transform 0.3s",
            "&:hover": { transform: "scale(1.05)" },
          }}
        />
      </Box>

      <CardContent sx={{ flex: 1, pb: 0.5 }}>
        {/* Title */}
        <Typography
          variant="body2"
          sx={{
            fontWeight: 500,
            color: "text.primary",
            mb: 1,
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
            lineHeight: 1.4,
          }}
        >
          {product.title}
        </Typography>

        {/* Rating */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.75, mb: 1 }}>
          <Rating value={product.rating} precision={0.5} readOnly size="small" sx={{ color: "secondary.main" }} />
          <Typography variant="caption" sx={{ color: "info.main" }}>
            {product.reviews.toLocaleString()}
          </Typography>
        </Box>

        {/* Pricing */}
        <Box sx={{ display: "flex", alignItems: "baseline", gap: 1, flexWrap: "wrap", mb: 0.5 }}>
          <Typography sx={{ fontSize: 22, fontWeight: 700, color: "text.primary", lineHeight: 1 }}>
            <sup style={{ fontSize: 13, verticalAlign: "super" }}>$</sup>
            {Math.floor(product.price)}
            <sup style={{ fontSize: 13, verticalAlign: "super" }}>
              {String(product.price.toFixed(2)).split(".")[1]}
            </sup>
          </Typography>
          <Typography variant="caption" sx={{ color: "text.secondary", textDecoration: "line-through" }}>
            ${product.originalPrice.toFixed(2)}
          </Typography>
          <Typography variant="caption" sx={{ color: "error.main", fontWeight: 700 }}>
            -{discount}%
          </Typography>
        </Box>

        {/* Prime */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
          <Chip
            label="prime"
            size="small"
            sx={{
              bgcolor: "#00A8E1",
              color: "#fff",
              fontSize: 10,
              fontWeight: 800,
              height: 18,
              letterSpacing: 0.5,
            }}
          />
          <Typography variant="caption" sx={{ color: "text.secondary" }}>
            FREE delivery
          </Typography>
        </Box>
      </CardContent>

      <CardActions sx={{ px: 2, pb: 2, pt: 1 }}>
        <Button
          fullWidth
          variant="contained"
          onClick={handleAdd}
          startIcon={added ? <CheckIcon /> : <AddShoppingCartIcon />}
          sx={{
            bgcolor: added ? "#067D62" : "#FFD814",
            color: added ? "#fff" : "primary.main",
            fontWeight: 700,
            fontSize: 13,
            py: 1,
            transition: "all 0.2s",
            "&:hover": {
              bgcolor: added ? "#056b54" : "#F7CA00",
              transform: "scale(1.01)",
            },
          }}
        >
          {added ? "Added to Cart" : "Add to Cart"}
        </Button>
      </CardActions>
    </Card>
  );
}
