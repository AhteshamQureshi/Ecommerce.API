import { Box, Typography, Grid, Link, Button, Divider } from "@mui/material";
import LanguageIcon from "@mui/icons-material/Language";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";

const footerLinks: Record<string, string[]> = {
  "Get to Know Us": ["About Amazon", "Careers", "Press Releases", "Amazon Cares"],
  "Make Money with Us": ["Sell on Amazon", "Become an Affiliate", "Advertise Your Products"],
  "Amazon Payment Products": ["Amazon Business Card", "Shop with Points", "Reload Your Balance"],
  "Let Us Help You": ["Your Account", "Your Orders", "Shipping Rates & Policies", "Help"],
};

export default function Footer() {
  return (
    <Box component="footer" sx={{ bgcolor: "primary.main", mt: 3 }}>
      <Button fullWidth onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        endIcon={<KeyboardArrowUpIcon />}
        sx={{ bgcolor: "#37475a", color: "#fff", borderRadius: 0, py: 1.5, fontSize: 13, fontWeight: 500, "&:hover": { bgcolor: "#485769" } }}>
        Back to top
      </Button>

      <Box sx={{ maxWidth: 1500, mx: "auto", px: 4, py: 5 }}>
        <Grid container spacing={3}>
          {Object.entries(footerLinks).map(([title, links]) => (
            <Grid key={title} size={{ xs: 6, md: 3 }}>
              <Typography variant="body2" sx={{ fontWeight: 700, color: "#fff", mb: 1.5 }}>{title}</Typography>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 0.75 }}>
                {links.map((link) => (
                  <Link key={link} href="#" underline="hover" sx={{ fontSize: 13, color: "#ddd", "&:hover": { color: "#fff" } }}>{link}</Link>
                ))}
              </Box>
            </Grid>
          ))}
        </Grid>
      </Box>

      <Divider sx={{ borderColor: "#3a4553" }} />

      <Box sx={{ py: 3, px: 4, textAlign: "center" }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 4, mb: 2, flexWrap: "wrap" }}>
          <Box>
            <Typography component="span" sx={{ fontSize: 20, fontWeight: 800, color: "#fff", fontFamily: "Georgia, serif" }}>amazon</Typography>
            <Typography component="sup" sx={{ fontSize: 9, color: "secondary.main", fontWeight: 700 }}>.clone</Typography>
          </Box>
          <Box sx={{ display: "flex", gap: 1.5, flexWrap: "wrap", justifyContent: "center" }}>
            {[{ icon: true, label: "English" }, { icon: false, label: "$ USD" }, { icon: false, label: "🇺🇸 United States" }].map(({ icon, label }) => (
              <Box key={label} sx={{ display: "flex", alignItems: "center", gap: 0.5, border: "1px solid #555", borderRadius: 1, px: 1.5, py: 0.75, cursor: "pointer", color: "#ddd", fontSize: 12, "&:hover": { borderColor: "#aaa", color: "#fff" }, transition: "all 0.15s" }}>
                {icon && <LanguageIcon sx={{ fontSize: 14 }} />}
                <Typography component="span" sx={{ fontSize: 12 }}>{label}</Typography>
              </Box>
            ))}
          </Box>
        </Box>
        <Typography variant="caption" sx={{ color: "#aaa" }}>
          © 1996–2026, Amazon Clone · Built with React + Vite + MUI v5 + TypeScript ·{" "}
          <Link href="#" underline="hover" sx={{ color: "#aaa" }}>Privacy</Link> ·{" "}
          <Link href="#" underline="hover" sx={{ color: "#aaa" }}>Conditions of Use</Link>
        </Typography>
      </Box>
    </Box>
  );
}
