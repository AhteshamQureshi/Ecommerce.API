import { useState } from "react";
import type { SelectChangeEvent } from "@mui/material";
import {
  AppBar, Toolbar, Box, InputBase, IconButton, Badge,
  Typography, Select, MenuItem, Button,
  useMediaQuery, useTheme,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import LocationOnOutlinedIcon from "@mui/icons-material/LocationOnOutlined";
import MenuIcon from "@mui/icons-material/Menu";

interface HeaderProps {
  cartCount: number;
  onCartClick: () => void;
}

const bottomNavItems = ["Today's Deals", "Customer Service", "Registry", "Gift Cards", "Sell", "Try Prime"];

export default function Header({ cartCount, onCartClick }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [category, setCategory] = useState<string>("All");
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const handleCategoryChange = (e: SelectChangeEvent) => setCategory(e.target.value);

  return (
    <AppBar position="sticky" sx={{ bgcolor: "primary.main", boxShadow: "none" }}>
      <Toolbar sx={{ gap: 1.5, px: { xs: 1.5, md: 2 }, minHeight: "60px !important" }}>
        {/* Logo */}
        <Box sx={{ border: "2px solid transparent", borderRadius: 1, px: 1, py: 0.5, cursor: "pointer", flexShrink: 0, "&:hover": { borderColor: "white" } }}>
          <Typography component="span" sx={{ fontSize: 26, fontWeight: 800, color: "#fff", fontFamily: "Georgia, serif", letterSpacing: -1 }}>
            amazon
          </Typography>
          <Typography component="sup" sx={{ fontSize: 10, color: "secondary.main", fontWeight: 700, verticalAlign: "super", ml: "2px" }}>
            .clone
          </Typography>
        </Box>

        {/* Deliver To */}
        {!isMobile && (
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, border: "2px solid transparent", borderRadius: 1, px: 1, py: 0.5, cursor: "pointer", flexShrink: 0, "&:hover": { borderColor: "white" } }}>
            <LocationOnOutlinedIcon sx={{ color: "#ccc", fontSize: 18 }} />
            <Box>
              <Typography variant="caption" sx={{ color: "#ccc", display: "block", lineHeight: 1.2 }}>Deliver to</Typography>
              <Typography variant="body2" sx={{ color: "#fff", fontWeight: 700, lineHeight: 1.2 }}>United States</Typography>
            </Box>
          </Box>
        )}

        {/* Search */}
        <Box sx={{ flex: 1, display: "flex", height: 40, borderRadius: 1.5, overflow: "hidden", outline: "2px solid", outlineColor: "secondary.main" }}>
          {!isMobile && (
            <Select value={category} onChange={handleCategoryChange} variant="standard" disableUnderline
              sx={{ bgcolor: "#f3f3f3", px: 1, fontSize: 12, minWidth: 80, borderRight: "1px solid #ccc", "& .MuiSelect-select": { py: "10px", pr: "24px !important", pl: 1 } }}>
              {["All", "Electronics", "Kitchen", "Books"].map((cat) => (
                <MenuItem key={cat} value={cat} sx={{ fontSize: 13 }}>{cat}</MenuItem>
              ))}
            </Select>
          )}
          <InputBase placeholder="Search Amazon Clone" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
            sx={{ flex: 1, bgcolor: "#fff", px: 1.5, fontSize: 14 }} />
          <Box sx={{ bgcolor: "secondary.main", display: "flex", alignItems: "center", px: 1.5, cursor: "pointer", "&:hover": { bgcolor: "#e88900" }, transition: "background 0.15s" }}>
            <SearchIcon sx={{ color: "primary.main" }} />
          </Box>
        </Box>

        {/* Account */}
        {!isMobile && (
          <Box sx={{ display: "flex", flexDirection: "column", border: "2px solid transparent", borderRadius: 1, px: 1, py: 0.5, cursor: "pointer", flexShrink: 0, "&:hover": { borderColor: "white" } }}>
            <Typography variant="caption" sx={{ color: "#ccc" }}>Hello, Sign in</Typography>
            <Typography variant="body2" sx={{ color: "#fff", fontWeight: 700 }}>Account & Lists ▾</Typography>
          </Box>
        )}

        {/* Orders */}
        {!isMobile && (
          <Box sx={{ display: "flex", flexDirection: "column", border: "2px solid transparent", borderRadius: 1, px: 1, py: 0.5, cursor: "pointer", flexShrink: 0, "&:hover": { borderColor: "white" } }}>
            <Typography variant="caption" sx={{ color: "#ccc" }}>Returns</Typography>
            <Typography variant="body2" sx={{ color: "#fff", fontWeight: 700 }}>&amp; Orders</Typography>
          </Box>
        )}

        {/* Cart */}
        <IconButton onClick={onCartClick}
          sx={{ color: "#fff", border: "2px solid transparent", borderRadius: 1, px: 1, "&:hover": { borderColor: "white", bgcolor: "transparent" }, display: "flex", alignItems: "center", gap: 0.5 }}>
          <Badge badgeContent={cartCount}
            sx={{ "& .MuiBadge-badge": { bgcolor: "secondary.main", color: "primary.main", fontWeight: 800, fontSize: 11, minWidth: 18, height: 18 } }}>
            <ShoppingCartOutlinedIcon />
          </Badge>
          <Typography variant="body2" sx={{ fontWeight: 700, color: "#fff" }}>Cart</Typography>
        </IconButton>

        {isMobile && <IconButton sx={{ color: "#fff" }}><MenuIcon /></IconButton>}
      </Toolbar>

      {/* Bottom Nav */}
      <Box sx={{ bgcolor: "primary.light", display: "flex", alignItems: "center", gap: 0.5, px: 2, overflowX: "auto", "&::-webkit-scrollbar": { display: "none" } }}>
        <Button startIcon={<MenuIcon sx={{ fontSize: "16px !important" }} />}
          sx={{ color: "#fff", fontSize: 13, fontWeight: 700, py: 0.8, px: 1.5, border: "2px solid transparent", borderRadius: 1, whiteSpace: "nowrap", "&:hover": { borderColor: "white", bgcolor: "transparent" } }}>
          All
        </Button>
        {bottomNavItems.map((item) => (
          <Button key={item}
            sx={{ color: item === "Try Prime" ? "#00A8E1" : "#fff", fontSize: 13, fontWeight: item === "Try Prime" ? 700 : 400, py: 0.8, px: 1.5, border: "2px solid transparent", borderRadius: 1, whiteSpace: "nowrap", "&:hover": { borderColor: "white", bgcolor: "transparent" } }}>
            {item}
          </Button>
        ))}
      </Box>
    </AppBar>
  );
}
