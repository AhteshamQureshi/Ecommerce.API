import { Box, Typography, Button, Chip, useMediaQuery, useTheme } from "@mui/material";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import BoltIcon from "@mui/icons-material/Bolt";

export default function Hero() {
  const theme = useTheme();
  const isTablet = useMediaQuery(theme.breakpoints.down("lg"));
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  return (
    <Box sx={{ maxWidth: 1500, mx: "auto", px: 2, py: 1, display: "grid", gridTemplateColumns: isTablet ? "1fr" : "1fr 300px", gap: 1 }}>
      {/* ── Main Banner ── */}
      <Box
        sx={{
          background: "linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%)",
          borderRadius: 3,
          overflow: "hidden",
          display: "flex",
          alignItems: "center",
          p: { xs: 3, md: 5 },
          gap: 4,
          minHeight: 300,
          position: "relative",
        }}
      >
        <Box sx={{ flex: 1, zIndex: 1 }}>
          <Chip
            label="SUMMER SALE"
            size="small"
            sx={{
              bgcolor: "rgba(255,153,0,0.2)",
              color: "secondary.main",
              fontWeight: 800,
              letterSpacing: 1.5,
              fontSize: 10,
              mb: 1.5,
            }}
          />
          <Typography
            variant="h3"
            sx={{ color: "#fff", fontWeight: 800, fontSize: { xs: 24, md: 36 }, lineHeight: 1.15, mb: 1.5 }}
          >
            Up to 40% off Electronics
          </Typography>
          <Typography variant="body1" sx={{ color: "#b0c4d8", mb: 3, maxWidth: 380, lineHeight: 1.6 }}>
            Shop the biggest deals of the season — limited time only.
          </Typography>
          <Button
            variant="contained"
            color="secondary"
            endIcon={<ArrowForwardIcon />}
            sx={{
              fontWeight: 700,
              px: 3,
              py: 1.2,
              fontSize: 15,
              "&:hover": { transform: "translateY(-2px)", boxShadow: "0 8px 24px rgba(255,153,0,0.4)" },
              transition: "transform 0.15s, box-shadow 0.15s",
            }}
          >
            Shop Now
          </Button>
        </Box>

        {!isMobile && (
          <Box sx={{ position: "relative", flexShrink: 0 }}>
            <Box
              component="img"
              src="https://images.unsplash.com/photo-1498049794561-7780e7231661?w=600&h=400&fit=crop"
              alt="Electronics Sale"
              sx={{ width: 260, height: 190, objectFit: "cover", borderRadius: 2.5, boxShadow: "0 16px 48px rgba(0,0,0,0.4)", display: "block" }}
            />
            <Box
              sx={{
                position: "absolute",
                top: -14,
                right: -14,
                bgcolor: "secondary.main",
                color: "primary.main",
                borderRadius: "50%",
                width: 64,
                height: 64,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: 800,
                lineHeight: 1,
                boxShadow: "0 4px 16px rgba(255,153,0,0.5)",
              }}
            >
              <Typography sx={{ fontSize: 20, fontWeight: 800, lineHeight: 1 }}>40%</Typography>
              <Typography sx={{ fontSize: 10, fontWeight: 800 }}>OFF</Typography>
            </Box>
          </Box>
        )}
      </Box>

      {/* ── Side Column ── */}
      {!isTablet && (
        <Box sx={{ display: "flex", flexDirection: "column", gap: 1 }}>
          {/* Mini Banner */}
          <Box
            sx={{
              flex: 1,
              background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
              borderRadius: 3,
              p: 3,
              overflow: "hidden",
              position: "relative",
            }}
          >
            <Typography sx={{ fontSize: 10, fontWeight: 800, letterSpacing: 2, color: "#00A8E1", mb: 1 }}>
              NEW ARRIVALS
            </Typography>
            <Typography variant="h6" sx={{ color: "#fff", fontWeight: 800, fontSize: 18, lineHeight: 1.2, mb: 1.5 }}>
              Kitchen Essentials Reinvented
            </Typography>
            <Button
              sx={{ color: "#00A8E1", p: 0, fontSize: 13, fontWeight: 600, "&:hover": { bgcolor: "transparent", textDecoration: "underline" } }}
            >
              Explore More →
            </Button>
            <Box
              component="img"
              src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop"
              alt="Kitchen"
              sx={{ position: "absolute", bottom: 0, right: 0, width: 110, height: 80, objectFit: "cover", borderRadius: "8px 0 0 0", opacity: 0.55 }}
            />
          </Box>

          {/* Promo Strip */}
          <Box
            sx={{
              bgcolor: "primary.light",
              borderRadius: 2.5,
              p: 2,
              display: "flex",
              alignItems: "center",
              gap: 1.5,
            }}
          >
            <BoltIcon sx={{ color: "secondary.main", fontSize: 28, flexShrink: 0 }} />
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontSize: 14, fontWeight: 700, color: "secondary.main" }}>
                Lightning Deals
              </Typography>
              <Typography variant="caption" sx={{ color: "#aaa" }}>
                New deals every 5 minutes
              </Typography>
            </Box>
            <Button
              variant="contained"
              color="secondary"
              size="small"
              sx={{ fontSize: 12, fontWeight: 700, px: 1.5, flexShrink: 0 }}
            >
              View All
            </Button>
          </Box>
        </Box>
      )}
    </Box>
  );
}
