import { useState } from "react";
import { ThemeProvider, CssBaseline, Box } from "@mui/material";
import theme from "./theme";
import Header from "./components/Header";
import Hero from "./components/Hero";
import ProductGrid from "./components/ProductGrid";
import CartDrawer from "./components/CartDrawer";
import Footer from "./components/Footer";
import { products } from "./data/products";
import type { Product, CartItem } from "./types";

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  function handleAddToCart(product: Product): void {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, qty: item.qty + 1 } : item
        );
      }
      return [...prev, { ...product, qty: 1 }];
    });
  }

  function handleRemoveFromCart(productId: number): void {
    setCartItems((prev) => prev.filter((item) => item.id !== productId));
  }

  const cartCount: number = cartItems.reduce((sum, item) => sum + item.qty, 0);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ minHeight: "100vh", display: "flex", flexDirection: "column", bgcolor: "background.default" }}>
        <Header cartCount={cartCount} onCartClick={() => setIsCartOpen(true)} />
        <Box component="main" sx={{ flex: 1 }}>
          <Hero />
          <ProductGrid products={products} onAddToCart={handleAddToCart} />
        </Box>
        <Footer />
        <CartDrawer
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
          cartItems={cartItems}
          onRemove={handleRemoveFromCart}
        />
      </Box>
    </ThemeProvider>
  );
}
