import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: {
      main: "#131921",
      light: "#232f3e",
      contrastText: "#ffffff",
    },
    secondary: {
      main: "#FF9900",
      contrastText: "#131921",
    },
    background: {
      default: "#EAEDED",
      paper: "#ffffff",
    },
    error: {
      main: "#cc0c39",
    },
    info: {
      main: "#007185",
    },
    text: {
      primary: "#0f1111",
      secondary: "#565959",
    },
  },
  typography: {
    fontFamily: '"Amazon Ember", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
    h1: { fontWeight: 800 },
    h2: { fontWeight: 700 },
    h3: { fontWeight: 700 },
    h6: { fontWeight: 700 },
    button: { textTransform: "none", fontWeight: 600 },
  },
  shape: {
    borderRadius: 8,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 20,
          boxShadow: "none",
          "&:hover": { boxShadow: "none" },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
          transition: "box-shadow 0.2s, transform 0.2s",
          "&:hover": {
            boxShadow: "0 8px 32px rgba(0,0,0,0.15)",
            transform: "translateY(-3px)",
          },
        },
      },
    },
  },
});

export default theme;
