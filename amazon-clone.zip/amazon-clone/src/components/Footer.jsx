import "./Footer.css";

const footerLinks = {
  "Get to Know Us": ["About Amazon", "Careers", "Press Releases", "Amazon Cares", "Gift a Smile"],
  "Make Money with Us": ["Sell products on Amazon", "Sell on Amazon Business", "Become an Affiliate", "Advertise Your Products"],
  "Amazon Payment Products": ["Amazon Business Card", "Shop with Points", "Reload Your Balance", "Amazon Currency Converter"],
  "Let Us Help You": ["Your Account", "Your Orders", "Shipping Rates & Policies", "Returns & Replacements", "Help"],
};

export default function Footer() {
  return (
    <footer className="footer">
      <button className="footer__back-top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
        Back to top
      </button>

      <div className="footer__main">
        <div className="footer__grid">
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title} className="footer__col">
              <h4 className="footer__col-title">{title}</h4>
              <ul className="footer__col-links">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#" className="footer__link">{link}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      <div className="footer__bottom">
        <div className="footer__bottom-inner">
          <div className="footer__logo">
            <span className="footer-logo-text">amazon</span>
            <span className="footer-logo-dot">.clone</span>
          </div>
          <div className="footer__locale">
            <span className="locale-btn">🌐 English</span>
            <span className="locale-btn">$ USD</span>
            <span className="locale-btn">🇺🇸 United States</span>
          </div>
        </div>
        <p className="footer__copy">
          © 1996–2026, Amazon Clone, Inc. or its affiliates · Built with React + Vite ·{" "}
          <a href="#" className="footer__link">Privacy Notice</a> ·{" "}
          <a href="#" className="footer__link">Conditions of Use</a>
        </p>
      </div>
    </footer>
  );
}
