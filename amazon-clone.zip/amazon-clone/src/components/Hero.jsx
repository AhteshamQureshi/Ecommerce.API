import "./Hero.css";

const banners = [
  {
    id: 1,
    tag: "SUMMER SALE",
    headline: "Up to 40% off Electronics",
    sub: "Shop the biggest deals of the season — limited time only.",
    cta: "Shop Now",
    bg: "linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%)",
    accent: "#FF9900",
    img: "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=600&h=400&fit=crop",
  },
  {
    id: 2,
    tag: "NEW ARRIVALS",
    headline: "Kitchen Essentials\nReinvented",
    sub: "Smart appliances for the modern home chef.",
    cta: "Explore More",
    bg: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
    accent: "#00A8E1",
    img: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop",
  },
];

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero__main" style={{ background: banners[0].bg }}>
        <div className="hero__content">
          <span className="hero__tag" style={{ color: banners[0].accent }}>
            {banners[0].tag}
          </span>
          <h1 className="hero__headline">{banners[0].headline}</h1>
          <p className="hero__sub">{banners[0].sub}</p>
          <button className="hero__cta" style={{ background: banners[0].accent }}>
            {banners[0].cta}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <line x1="5" y1="12" x2="19" y2="12"/>
              <polyline points="12 5 19 12 12 19"/>
            </svg>
          </button>
        </div>
        <div className="hero__image-wrap">
          <img src={banners[0].img} alt="Electronics Sale" className="hero__image" />
          <div className="hero__badge">
            <span className="badge-pct">40%</span>
            <span className="badge-off">OFF</span>
          </div>
        </div>
      </div>

      <div className="hero__side">
        {banners[1] && (
          <div className="hero__mini" style={{ background: banners[1].bg }}>
            <span className="mini__tag" style={{ color: banners[1].accent }}>{banners[1].tag}</span>
            <h3 className="mini__headline">{banners[1].headline}</h3>
            <button className="mini__cta">{banners[1].cta} →</button>
            <img src={banners[1].img} alt="" className="mini__image" />
          </div>
        )}
        <div className="hero__promo">
          <div className="promo-icon">⚡</div>
          <div>
            <p className="promo-title">Lightning Deals</p>
            <p className="promo-sub">New deals every 5 minutes</p>
          </div>
          <button className="promo-btn">View All</button>
        </div>
      </div>
    </section>
  );
}
