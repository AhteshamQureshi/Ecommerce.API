import ProductCard from "./ProductCard";
import "./ProductGrid.css";

export default function ProductGrid({ products, onAddToCart }) {
  return (
    <section className="product-section">
      <div className="product-section__header">
        <h2 className="product-section__title">Best Sellers</h2>
        <p className="product-section__sub">Our most popular products based on sales</p>
        <a href="#" className="product-section__link">See all best sellers →</a>
      </div>
      <div className="product-grid">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onAddToCart={onAddToCart}
          />
        ))}
      </div>
    </section>
  );
}
