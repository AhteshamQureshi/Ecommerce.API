import { useState } from "react";
import "./Header.css";

export default function Header({ cartCount, onCartClick }) {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <header className="header">
      <div className="header__top">
        {/* Logo */}
        <div className="header__logo">
          <span className="logo-text">amazon</span>
          <span className="logo-dot">.clone</span>
        </div>

        {/* Deliver To */}
        <div className="header__deliver">
          <span className="deliver-icon">📍</span>
          <div>
            <span className="deliver-label">Deliver to</span>
            <span className="deliver-location">United States</span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="header__search">
          <select className="search__category">
            <option>All</option>
            <option>Electronics</option>
            <option>Books</option>
            <option>Kitchen</option>
          </select>
          <input
            type="text"
            className="search__input"
            placeholder="Search Amazon Clone"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button className="search__btn" aria-label="Search">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </button>
        </div>

        {/* Right Nav */}
        <nav className="header__nav">
          <div className="nav-item">
            <span className="nav-label">Hello, Sign in</span>
            <span className="nav-value">Account & Lists ▾</span>
          </div>
          <div className="nav-item">
            <span className="nav-label">Returns</span>
            <span className="nav-value">& Orders</span>
          </div>
          <button className="cart-btn" onClick={onCartClick} aria-label="Cart">
            <div className="cart-icon-wrap">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
                <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" opacity="0.15"/>
                <path d="M3 6h18M16 10a4 4 0 01-8 0" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/>
                <rect x="2" y="5" width="20" height="15" rx="1" stroke="currentColor" strokeWidth="1.5" fill="none"/>
              </svg>
              {cartCount > 0 && (
                <span className="cart-count">{cartCount}</span>
              )}
            </div>
            <span className="nav-value">Cart</span>
          </button>
        </nav>
      </div>

      {/* Bottom Nav Bar */}
      <div className="header__bottom">
        <button className="bottom-nav__all">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
          </svg>
          All
        </button>
        {["Today's Deals", "Customer Service", "Registry", "Gift Cards", "Sell"].map((item) => (
          <button key={item} className="bottom-nav__item">{item}</button>
        ))}
        <button className="bottom-nav__item bottom-nav__prime">Try Prime</button>
      </div>
    </header>
  );
}
