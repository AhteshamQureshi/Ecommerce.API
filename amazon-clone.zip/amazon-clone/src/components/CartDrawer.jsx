import "./CartDrawer.css";

export default function CartDrawer({ isOpen, onClose, cartItems, onRemove }) {
  const total = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);

  return (
    <>
      <div className={`cart-overlay ${isOpen ? "cart-overlay--open" : ""}`} onClick={onClose} />
      <aside className={`cart-drawer ${isOpen ? "cart-drawer--open" : ""}`}>
        <div className="cart-drawer__header">
          <h2 className="cart-drawer__title">
            Shopping Cart
            {cartItems.length > 0 && (
              <span className="cart-drawer__count">{cartItems.reduce((s, i) => s + i.qty, 0)}</span>
            )}
          </h2>
          <button className="cart-drawer__close" onClick={onClose} aria-label="Close cart">✕</button>
        </div>

        <div className="cart-drawer__body">
          {cartItems.length === 0 ? (
            <div className="cart-empty">
              <div className="cart-empty__icon">🛒</div>
              <p className="cart-empty__text">Your cart is empty</p>
              <p className="cart-empty__sub">Add items to get started</p>
              <button className="cart-empty__btn" onClick={onClose}>Continue Shopping</button>
            </div>
          ) : (
            <ul className="cart-list">
              {cartItems.map((item) => (
                <li key={item.id} className="cart-item">
                  <img src={item.image} alt={item.title} className="cart-item__img" />
                  <div className="cart-item__info">
                    <p className="cart-item__title">{item.title}</p>
                    <p className="cart-item__price">${item.price.toFixed(2)} × {item.qty}</p>
                    <button className="cart-item__remove" onClick={() => onRemove(item.id)}>
                      Remove
                    </button>
                  </div>
                  <span className="cart-item__subtotal">${(item.price * item.qty).toFixed(2)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {cartItems.length > 0 && (
          <div className="cart-drawer__footer">
            <div className="cart-total">
              <span>Subtotal ({cartItems.reduce((s, i) => s + i.qty, 0)} items)</span>
              <span className="cart-total__amount">${total.toFixed(2)}</span>
            </div>
            <button className="cart-checkout">Proceed to Checkout</button>
            <p className="cart-footer__note">Taxes calculated at checkout · Free shipping on orders over $25</p>
          </div>
        )}
      </aside>
    </>
  );
}
