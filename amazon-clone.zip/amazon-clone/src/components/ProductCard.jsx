import { useState } from "react";
import "./ProductCard.css";

function StarRating({ rating }) {
  return (
    <div className="stars" aria-label={`${rating} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((star) => {
        const filled = rating >= star;
        const half = !filled && rating >= star - 0.5;
        return (
          <span key={star} className={`star ${filled ? "star--full" : half ? "star--half" : "star--empty"}`}>
            ★
          </span>
        );
      })}
    </div>
  );
}

export default function ProductCard({ product, onAddToCart }) {
  const [added, setAdded] = useState(false);

  const discount = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  function handleAdd() {
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  }

  return (
    <article className="card">
      {product.badge && (
        <span className={`card__badge card__badge--${product.badge === "Deal" || product.badge === "Limited Deal" ? "deal" : "choice"}`}>
          {product.badge}
        </span>
      )}

      <div className="card__img-wrap">
        <img
          src={product.image}
          alt={product.title}
          className="card__img"
          loading="lazy"
        />
      </div>

      <div className="card__body">
        <h3 className="card__title">{product.title}</h3>

        <div className="card__rating">
          <StarRating rating={product.rating} />
          <span className="card__review-count">
            {product.reviews.toLocaleString()}
          </span>
        </div>

        <div className="card__pricing">
          <span className="card__price">
            <sup className="price-sup">$</sup>
            {Math.floor(product.price)}
            <sup className="price-cents">{String(product.price.toFixed(2)).split(".")[1]}</sup>
          </span>
          <div className="card__meta">
            <span className="card__original">${product.originalPrice.toFixed(2)}</span>
            <span className="card__discount">-{discount}%</span>
          </div>
        </div>

        <p className="card__prime">
          <span className="prime-badge">prime</span> FREE delivery
        </p>

        <button
          className={`card__btn ${added ? "card__btn--added" : ""}`}
          onClick={handleAdd}
        >
          {added ? (
            <>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              Added to Cart
            </>
          ) : (
            "Add to Cart"
          )}
        </button>
      </div>
    </article>
  );
}
