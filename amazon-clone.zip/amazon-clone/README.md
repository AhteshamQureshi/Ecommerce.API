# Amazon Clone — React + Vite

A beginner-friendly e-commerce frontend inspired by Amazon.

## 🚀 Getting Started

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

## 📁 Project Structure

```
src/
├── components/
│   ├── Header.jsx / Header.css       # Sticky header with search + cart
│   ├── Hero.jsx / Hero.css           # Banner section
│   ├── ProductGrid.jsx / .css        # Grid layout
│   ├── ProductCard.jsx / .css        # Individual product cards
│   ├── CartDrawer.jsx / .css         # Slide-out cart sidebar
│   └── Footer.jsx / Footer.css       # Site footer
├── data/
│   └── products.js                   # 8 sample products
├── styles/
│   └── global.css                    # Base styles
├── App.jsx                           # Root component + cart state
└── main.jsx                          # Entry point
```

## ✨ Features

- Sticky header with logo, search bar, and cart icon
- Hero banner with sale callout and side panels
- 8 product cards with ratings, pricing, discounts, and badges
- "Add to Cart" button with animated feedback
- Slide-out cart drawer with quantity tracking and remove
- Fully responsive down to mobile (320px)
- Clean CSS modules, no third-party UI libraries
