using EcommerceReadOnly.API.Models;

namespace EcommerceReadOnly.API.Data;

public static class DataStore
{
    public static List<Category> Categories { get; } =
    [
        new() { Id = 1, Name = "Electronics",      Description = "Gadgets, phones, laptops and more",   ImageUrl = "https://placehold.co/400x300?text=Electronics"  },
        new() { Id = 2, Name = "Clothing",          Description = "Fashion for men, women and kids",      ImageUrl = "https://placehold.co/400x300?text=Clothing"      },
        new() { Id = 3, Name = "Books",             Description = "Fiction, non-fiction, textbooks",      ImageUrl = "https://placehold.co/400x300?text=Books"         },
        new() { Id = 4, Name = "Home & Kitchen",    Description = "Furniture, appliances and decor",      ImageUrl = "https://placehold.co/400x300?text=Home+Kitchen"  },
        new() { Id = 5, Name = "Sports & Outdoors", Description = "Equipment and gear for every sport",   ImageUrl = "https://placehold.co/400x300?text=Sports"        },
        new() { Id = 6, Name = "Toys & Games",      Description = "Fun for all ages",                     ImageUrl = "https://placehold.co/400x300?text=Toys"          },
    ];

    public static List<Product> Products { get; } =
    [
        // Electronics
        new() { Id = 1,  Name = "iPhone 16 Pro",          Description = "Latest Apple flagship with A18 chip",          Price = 999.99m,  DiscountPrice = 949.99m, Stock = 50,  CategoryId = 1, Brand = "Apple",   ImageUrl = "https://placehold.co/400?text=iPhone16Pro",   Rating = 4.8, ReviewCount = 1240 },
        new() { Id = 2,  Name = "Samsung Galaxy S25",      Description = "Android powerhouse with 200MP camera",         Price = 899.99m,  DiscountPrice = null,    Stock = 35,  CategoryId = 1, Brand = "Samsung", ImageUrl = "https://placehold.co/400?text=GalaxyS25",     Rating = 4.7, ReviewCount = 980  },
        new() { Id = 3,  Name = "MacBook Pro 14\"",        Description = "M4 chip, 16GB RAM, 512GB SSD",                 Price = 1999.00m, DiscountPrice = null,    Stock = 20,  CategoryId = 1, Brand = "Apple",   ImageUrl = "https://placehold.co/400?text=MacBookPro",    Rating = 4.9, ReviewCount = 620  },
        new() { Id = 4,  Name = "Sony WH-1000XM6",         Description = "Industry-leading noise-cancelling headphones", Price = 399.99m,  DiscountPrice = 349.99m, Stock = 80,  CategoryId = 1, Brand = "Sony",    ImageUrl = "https://placehold.co/400?text=SonyWH1000XM6", Rating = 4.8, ReviewCount = 3200 },
        new() { Id = 5,  Name = "Dell 27\" 4K Monitor",    Description = "UHD IPS panel, 144Hz refresh rate",            Price = 549.00m,  DiscountPrice = 499.00m, Stock = 30,  CategoryId = 1, Brand = "Dell",    ImageUrl = "https://placehold.co/400?text=DellMonitor",   Rating = 4.6, ReviewCount = 450  },

        // Clothing
        new() { Id = 6,  Name = "Classic White T-Shirt",   Description = "100% organic cotton, relaxed fit",             Price = 29.99m,   DiscountPrice = null,    Stock = 200, CategoryId = 2, Brand = "H&M",     ImageUrl = "https://placehold.co/400?text=WhiteTShirt",   Rating = 4.3, ReviewCount = 870  },
        new() { Id = 7,  Name = "Slim-Fit Jeans",           Description = "Stretch denim, multiple washes",               Price = 79.99m,   DiscountPrice = 59.99m,  Stock = 150, CategoryId = 2, Brand = "Levi's",  ImageUrl = "https://placehold.co/400?text=SlimJeans",     Rating = 4.5, ReviewCount = 1100 },
        new() { Id = 8,  Name = "Running Sneakers",         Description = "Lightweight mesh upper, cushioned sole",       Price = 119.99m,  DiscountPrice = null,    Stock = 90,  CategoryId = 2, Brand = "Nike",    ImageUrl = "https://placehold.co/400?text=Sneakers",      Rating = 4.6, ReviewCount = 760  },

        // Books
        new() { Id = 9,  Name = "Clean Code",               Description = "A handbook of agile software craftsmanship",  Price = 45.00m,   DiscountPrice = 39.00m,  Stock = 100, CategoryId = 3, Brand = "Pearson", ImageUrl = "https://placehold.co/400?text=CleanCode",     Rating = 4.9, ReviewCount = 5400 },
        new() { Id = 10, Name = "The Pragmatic Programmer",  Description = "Your journey to mastery, 20th anniversary",  Price = 49.99m,   DiscountPrice = null,    Stock = 75,  CategoryId = 3, Brand = "Addison", ImageUrl = "https://placehold.co/400?text=PragProg",      Rating = 4.8, ReviewCount = 3100 },

        // Home & Kitchen
        new() { Id = 11, Name = "Instant Pot Duo 7-in-1",   Description = "Electric pressure cooker, 6-quart",           Price = 89.99m,   DiscountPrice = 69.99m,  Stock = 60,  CategoryId = 4, Brand = "Instant", ImageUrl = "https://placehold.co/400?text=InstantPot",    Rating = 4.7, ReviewCount = 12000},
        new() { Id = 12, Name = "Dyson V15 Vacuum",          Description = "Cordless vacuum with laser dust detection",   Price = 749.99m,  DiscountPrice = null,    Stock = 25,  CategoryId = 4, Brand = "Dyson",   ImageUrl = "https://placehold.co/400?text=DysonV15",      Rating = 4.8, ReviewCount = 2300 },

        // Sports
        new() { Id = 13, Name = "Yoga Mat Pro",              Description = "Non-slip, eco-friendly, 6mm thick",           Price = 59.99m,   DiscountPrice = null,    Stock = 120, CategoryId = 5, Brand = "Gaiam",   ImageUrl = "https://placehold.co/400?text=YogaMat",       Rating = 4.5, ReviewCount = 890  },
        new() { Id = 14, Name = "Adjustable Dumbbells Set",  Description = "5-52.5 lbs, space-saving design",             Price = 349.00m,  DiscountPrice = 299.00m, Stock = 40,  CategoryId = 5, Brand = "Bowflex", ImageUrl = "https://placehold.co/400?text=Dumbbells",     Rating = 4.7, ReviewCount = 1500 },

        // Toys
        new() { Id = 15, Name = "LEGO Technic Bugatti",      Description = "3599-piece supercar model, 1:8 scale",        Price = 449.99m,  DiscountPrice = 399.99m, Stock = 15,  CategoryId = 6, Brand = "LEGO",    ImageUrl = "https://placehold.co/400?text=LEGOBugatti",   Rating = 4.9, ReviewCount = 640  },
    ];
}
