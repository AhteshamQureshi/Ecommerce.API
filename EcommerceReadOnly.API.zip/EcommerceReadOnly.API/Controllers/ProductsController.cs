using EcommerceReadOnly.API.DTOs;
using EcommerceReadOnly.API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EcommerceReadOnly.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class ProductsController(IProductService productService) : ControllerBase
{
    /// <summary>
    /// Get all products with optional filters and pagination.
    /// </summary>
    /// <remarks>
    /// Query params: search, categoryId, brand, minPrice, maxPrice, sortBy (name|price|rating), sortOrder (asc|desc), page, pageSize
    /// </remarks>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<ProductDto>), 200)]
    public IActionResult GetAll([FromQuery] ProductFilterRequest filter)
    {
        var result = productService.GetAll(filter);
        return Ok(result);
    }

    /// <summary>Get a single product by ID.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ProductDto), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetById(int id)
    {
        var product = productService.GetById(id);
        if (product is null)
            return NotFound(new { message = $"Product {id} not found." });

        return Ok(product);
    }

    /// <summary>Get all products currently on sale (have a discount price).</summary>
    [HttpGet("on-sale")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    public IActionResult GetOnSale()
    {
        var products = productService.GetOnSale();
        return Ok(products);
    }

    /// <summary>Get top rated products.</summary>
    [HttpGet("top-rated")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    public IActionResult GetTopRated([FromQuery] int count = 5)
    {
        var products = productService.GetTopRated(count);
        return Ok(products);
    }

    /// <summary>Get a distinct list of all available brands.</summary>
    [HttpGet("brands")]
    [ProducesResponseType(typeof(List<string>), 200)]
    public IActionResult GetBrands()
    {
        var brands = productService.GetAllBrands();
        return Ok(brands);
    }
}
