using EcommerceReadOnly.API.Data;
using EcommerceReadOnly.API.DTOs;
using EcommerceReadOnly.API.Services.Interfaces;

namespace EcommerceReadOnly.API.Services;

public class CategoryService : ICategoryService
{
    public List<CategoryDto> GetAll()
    {
        return DataStore.Categories.Select(c => new CategoryDto
        {
            Id           = c.Id,
            Name         = c.Name,
            Description  = c.Description,
            ImageUrl     = c.ImageUrl,
            ProductCount = DataStore.Products.Count(p => p.CategoryId == c.Id)
        }).ToList();
    }

    public CategoryDto? GetById(int id)
    {
        var c = DataStore.Categories.FirstOrDefault(c => c.Id == id);
        if (c is null) return null;

        return new CategoryDto
        {
            Id           = c.Id,
            Name         = c.Name,
            Description  = c.Description,
            ImageUrl     = c.ImageUrl,
            ProductCount = DataStore.Products.Count(p => p.CategoryId == c.Id)
        };
    }
}
