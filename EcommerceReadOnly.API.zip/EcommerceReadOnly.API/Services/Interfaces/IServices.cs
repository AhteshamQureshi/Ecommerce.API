using EcommerceReadOnly.API.DTOs;

namespace EcommerceReadOnly.API.Services.Interfaces;

public interface ICategoryService
{
    List<CategoryDto> GetAll();
    CategoryDto? GetById(int id);
}

public interface IProductService
{
    PagedResult<ProductDto> GetAll(ProductFilterRequest filter);
    ProductDto? GetById(int id);
    List<ProductDto> GetByCategory(int categoryId);
    List<ProductDto> GetOnSale();
    List<ProductDto> GetTopRated(int count = 5);
    List<string> GetAllBrands();
}
