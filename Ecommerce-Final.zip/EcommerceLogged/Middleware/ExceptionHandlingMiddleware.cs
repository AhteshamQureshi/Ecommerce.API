using System.Text.Json;
using Ecommerce.Exceptions;
using Ecommerce.Models;
using Microsoft.Extensions.Logging;

namespace Ecommerce.Middleware;

/// <summary>
/// Global exception handling middleware.
/// Sits at the very top of the pipeline and catches ALL unhandled exceptions.
/// Maps each exception type to the correct HTTP status code and returns
/// a consistent JSON error response following RFC 7807 Problem Details.
/// </summary>
public class ExceptionHandlingMiddleware(
    RequestDelegate next,
    ILogger<ExceptionHandlingMiddleware> logger)
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (Exception ex)
        {
            await HandleExceptionAsync(context, ex);
        }
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        var traceId = context.TraceIdentifier;
        var path    = context.Request.Path;
        var method  = context.Request.Method;

        // ── Map exception type to HTTP response ───────────────────────────────
        var errorResponse = exception switch
        {
            // Known application exceptions → use their own StatusCode + ErrorCode
            AppException appEx => HandleAppException(appEx, path, traceId),

            // Unknown exceptions → 500 Internal Server Error
            _ => HandleUnknownException(exception, path, traceId)
        };

        // ── Log at the appropriate level ──────────────────────────────────────
        LogException(exception, errorResponse, method, path, traceId);

        // ── Write JSON response ───────────────────────────────────────────────
        context.Response.ContentType = "application/json";
        context.Response.StatusCode  = errorResponse.StatusCode;

        await context.Response.WriteAsync(
            JsonSerializer.Serialize(errorResponse, JsonOptions));
    }

    // ── Exception → ErrorResponse mappers ────────────────────────────────────

    private static ErrorResponse HandleAppException(
        AppException ex, string path, string traceId) => new()
    {
        StatusCode = ex.StatusCode,
        ErrorCode  = ex.ErrorCode,
        Message    = ex.Message,
        Path       = path,
        TraceId    = traceId,
        Details    = ex.Details
    };

    private static ErrorResponse HandleUnknownException(
        Exception ex, string path, string traceId) => new()
    {
        StatusCode = 500,
        ErrorCode  = "INTERNAL_SERVER_ERROR",
        Message    = "An unexpected error occurred. Please try again later.",
        Path       = path,
        TraceId    = traceId
    };

    // ── Log level based on severity ───────────────────────────────────────────

    private void LogException(
        Exception exception,
        ErrorResponse errorResponse,
        string method,
        string path,
        string traceId)
    {
        var logMessage =
            "[TraceId: {TraceId}] {Method} {Path} threw {ExceptionType} → " +
            "StatusCode: {StatusCode}, ErrorCode: {ErrorCode}, Message: {Message}";

        var args = new object[]
        {
            traceId,
            method,
            path,
            exception.GetType().Name,
            errorResponse.StatusCode,
            errorResponse.ErrorCode,
            exception.Message
        };

        // 4xx = Warning (client's fault), 5xx = Error (our fault)
        if (errorResponse.StatusCode >= 500)
            logger.LogError(exception, logMessage, args);
        else if (errorResponse.StatusCode >= 400)
            logger.LogWarning(logMessage, args);
        else
            logger.LogInformation(logMessage, args);
    }
}
