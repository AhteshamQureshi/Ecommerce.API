using Ecommerce.DTOs;

namespace Ecommerce.Services.Interfaces;

public interface ICategoryService
{
    List<CategoryDto> GetAll();
    CategoryDto GetById(int id);         // Throws CategoryNotFoundException if not found
}

public interface IProductService
{
    PagedResult<ProductDto> GetAll(ProductFilterRequest filter);
    ProductDto GetById(int id);          // Throws ProductNotFoundException if not found
    List<ProductDto> GetByCategory(int categoryId);
    List<ProductDto> GetOnSale();
    List<ProductDto> GetTopRated(int count = 5);
    List<string> GetAllBrands();
}
