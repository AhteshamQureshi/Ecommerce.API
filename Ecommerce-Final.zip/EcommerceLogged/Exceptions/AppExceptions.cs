namespace Ecommerce.Exceptions;

/// <summary>
/// Base class for all application-specific exceptions.
/// Every custom exception in this app inherits from this.
/// </summary>
public abstract class AppException : Exception
{
    public int StatusCode { get; }
    public string ErrorCode { get; }   // Machine-readable code e.g. "PRODUCT_NOT_FOUND"
    public object? Details { get; }    // Optional extra info (e.g. validation errors)

    protected AppException(
        string message,
        int statusCode,
        string errorCode,
        object? details = null)
        : base(message)
    {
        StatusCode = statusCode;
        ErrorCode  = errorCode;
        Details    = details;
    }
}

// ── 400 Bad Request ───────────────────────────────────────────────────────────

/// <summary>Thrown when the request data is invalid.</summary>
public class BadRequestException : AppException
{
    public BadRequestException(string message, object? details = null)
        : base(message, 400, "BAD_REQUEST", details) { }
}

/// <summary>Thrown when query parameters fail validation.</summary>
public class ValidationException : AppException
{
    public ValidationException(string message, object? details = null)
        : base(message, 400, "VALIDATION_ERROR", details) { }
}

// ── 404 Not Found ─────────────────────────────────────────────────────────────

/// <summary>Thrown when a requested resource does not exist.</summary>
public class NotFoundException : AppException
{
    public NotFoundException(string resourceName, object key)
        : base($"{resourceName} with ID '{key}' was not found.", 404, "RESOURCE_NOT_FOUND") { }

    public NotFoundException(string message)
        : base(message, 404, "RESOURCE_NOT_FOUND") { }
}

/// <summary>Thrown specifically when a product is not found.</summary>
public class ProductNotFoundException : NotFoundException
{
    public ProductNotFoundException(int id)
        : base("Product", id) { }
}

/// <summary>Thrown specifically when a category is not found.</summary>
public class CategoryNotFoundException : NotFoundException
{
    public CategoryNotFoundException(int id)
        : base("Category", id) { }
}

// ── 409 Conflict ─────────────────────────────────────────────────────────────

/// <summary>Thrown when a resource already exists (e.g. duplicate name).</summary>
public class ConflictException : AppException
{
    public ConflictException(string message)
        : base(message, 409, "CONFLICT") { }
}

// ── 500 Internal Server Error ─────────────────────────────────────────────────

/// <summary>Thrown for unexpected internal errors.</summary>
public class InternalServerException : AppException
{
    public InternalServerException(string message = "An unexpected error occurred.")
        : base(message, 500, "INTERNAL_SERVER_ERROR") { }
}
