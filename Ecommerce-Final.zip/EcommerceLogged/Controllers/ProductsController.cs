using Ecommerce.DTOs;
using Ecommerce.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Ecommerce.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class ProductsController(
    IProductService productService,
    ILogger<ProductsController> logger) : ControllerBase
{
    /// <summary>Get all products with optional filters and pagination.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<ProductDto>), 200)]
    [ProducesResponseType(typeof(ErrorResponse), 400)]
    public IActionResult GetAll([FromQuery] ProductFilterRequest filter)
    {
        logger.LogInformation("GET /api/products called");
        var result = productService.GetAll(filter);
        return Ok(result);
    }

    /// <summary>Get a single product by ID.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ProductDto), 200)]
    [ProducesResponseType(typeof(ErrorResponse), 404)]
    [ProducesResponseType(typeof(ErrorResponse), 400)]
    public IActionResult GetById(int id)
    {
        logger.LogInformation("GET /api/products/{ProductId} called", id);
        var product = productService.GetById(id);
        return Ok(product);
    }

    /// <summary>Get all products currently on sale.</summary>
    [HttpGet("on-sale")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    public IActionResult GetOnSale()
    {
        logger.LogInformation("GET /api/products/on-sale called");
        var products = productService.GetOnSale();
        return Ok(products);
    }

    /// <summary>Get top rated products.</summary>
    [HttpGet("top-rated")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    [ProducesResponseType(typeof(ErrorResponse), 400)]
    public IActionResult GetTopRated([FromQuery] int count = 5)
    {
        logger.LogInformation("GET /api/products/top-rated called with Count: {Count}", count);
        var products = productService.GetTopRated(count);
        return Ok(products);
    }

    /// <summary>Get a distinct list of all available brands.</summary>
    [HttpGet("brands")]
    [ProducesResponseType(typeof(List<string>), 200)]
    public IActionResult GetBrands()
    {
        logger.LogInformation("GET /api/products/brands called");
        var brands = productService.GetAllBrands();
        return Ok(brands);
    }
}
