using Ecommerce.DTOs;
using Ecommerce.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Ecommerce.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class CategoriesController(
    ICategoryService categoryService,
    ILogger<CategoriesController> logger) : ControllerBase
{
    /// <summary>Get all categories with product count.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<CategoryDto>), 200)]
    public IActionResult GetAll()
    {
        logger.LogInformation("GET /api/categories called");
        var categories = categoryService.GetAll();
        return Ok(categories);
    }

    /// <summary>Get a single category by ID.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(CategoryDto), 200)]
    [ProducesResponseType(typeof(ErrorResponse), 404)]
    [ProducesResponseType(typeof(ErrorResponse), 400)]
    public IActionResult GetById(int id)
    {
        logger.LogInformation("GET /api/categories/{CategoryId} called", id);
        // Service throws CategoryNotFoundException if not found
        // Middleware catches it and returns 404 automatically
        var category = categoryService.GetById(id);
        return Ok(category);
    }

    /// <summary>Get all products belonging to a category.</summary>
    [HttpGet("{id:int}/products")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    [ProducesResponseType(typeof(ErrorResponse), 404)]
    public IActionResult GetProducts(int id, [FromServices] IProductService productService)
    {
        logger.LogInformation("GET /api/categories/{CategoryId}/products called", id);
        var products = productService.GetByCategory(id);
        return Ok(products);
    }
}
