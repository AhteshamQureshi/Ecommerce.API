namespace Ecommerce.Models;

/// <summary>
/// Standard error response returned by the API for all errors.
/// Follows RFC 7807 "Problem Details for HTTP APIs" structure.
/// </summary>
public class ErrorResponse
{
    /// <summary>HTTP status code e.g. 400, 404, 500</summary>
    public int StatusCode { get; set; }

    /// <summary>Machine-readable error code e.g. "PRODUCT_NOT_FOUND"</summary>
    public string ErrorCode { get; set; } = string.Empty;

    /// <summary>Human-readable error message</summary>
    public string Message { get; set; } = string.Empty;

    /// <summary>The request path that caused the error</summary>
    public string Path { get; set; } = string.Empty;

    /// <summary>When the error occurred (UTC)</summary>
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;

    /// <summary>Unique ID to trace this error in logs</summary>
    public string TraceId { get; set; } = string.Empty;

    /// <summary>Optional extra details (e.g. validation errors list)</summary>
    public object? Details { get; set; }
}
