using Ecommerce.DTOs;
using Ecommerce.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Ecommerce.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class CategoriesController(
    ICategoryService categoryService,
    ILogger<CategoriesController> logger) : ControllerBase
{
    /// <summary>Get all categories with product count.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<CategoryDto>), 200)]
    public IActionResult GetAll()
    {
        logger.LogInformation("GET /api/categories - Request received");

        var categories = categoryService.GetAll();

        logger.LogInformation("GET /api/categories - Returning {Count} categories", categories.Count);
        return Ok(categories);
    }

    /// <summary>Get a single category by ID.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(CategoryDto), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetById(int id)
    {
        logger.LogInformation("GET /api/categories/{CategoryId} - Request received", id);

        var category = categoryService.GetById(id);

        if (category is null)
        {
            logger.LogWarning("GET /api/categories/{CategoryId} - Not found, returning 404", id);
            return NotFound(new { message = $"Category {id} not found." });
        }

        logger.LogInformation("GET /api/categories/{CategoryId} - Returning category: {CategoryName}",
            id, category.Name);
        return Ok(category);
    }

    /// <summary>Get all products belonging to a category.</summary>
    [HttpGet("{id:int}/products")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetProducts(int id, [FromServices] IProductService productService)
    {
        logger.LogInformation("GET /api/categories/{CategoryId}/products - Request received", id);

        var category = categoryService.GetById(id);

        if (category is null)
        {
            logger.LogWarning(
                "GET /api/categories/{CategoryId}/products - Category not found, returning 404", id);
            return NotFound(new { message = $"Category {id} not found." });
        }

        var products = productService.GetByCategory(id);

        logger.LogInformation(
            "GET /api/categories/{CategoryId}/products - Returning {Count} products for {CategoryName}",
            id, products.Count, category.Name);

        return Ok(products);
    }
}
