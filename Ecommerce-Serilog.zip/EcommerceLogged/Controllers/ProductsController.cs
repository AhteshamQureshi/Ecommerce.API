using Ecommerce.DTOs;
using Ecommerce.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Ecommerce.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class ProductsController(
    IProductService productService,
    ILogger<ProductsController> logger) : ControllerBase
{
    /// <summary>Get all products with optional filters and pagination.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<ProductDto>), 200)]
    public IActionResult GetAll([FromQuery] ProductFilterRequest filter)
    {
        logger.LogInformation(
            "GET /api/products - Request received with filters: " +
            "Search={Search}, CategoryId={CategoryId}, Brand={Brand}, " +
            "MinPrice={MinPrice}, MaxPrice={MaxPrice}, Page={Page}",
            filter.Search, filter.CategoryId, filter.Brand,
            filter.MinPrice, filter.MaxPrice, filter.Page);

        var result = productService.GetAll(filter);

        logger.LogInformation(
            "GET /api/products - Returning {Count} items (Total: {Total})",
            result.Items.Count, result.TotalCount);

        return Ok(result);
    }

    /// <summary>Get a single product by ID.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ProductDto), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetById(int id)
    {
        logger.LogInformation("GET /api/products/{ProductId} - Request received", id);

        var product = productService.GetById(id);

        if (product is null)
        {
            logger.LogWarning("GET /api/products/{ProductId} - Not found, returning 404", id);
            return NotFound(new { message = $"Product {id} not found." });
        }

        logger.LogInformation(
            "GET /api/products/{ProductId} - Returning product: {ProductName}",
            id, product.Name);

        return Ok(product);
    }

    /// <summary>Get all products currently on sale.</summary>
    [HttpGet("on-sale")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    public IActionResult GetOnSale()
    {
        logger.LogInformation("GET /api/products/on-sale - Request received");

        var products = productService.GetOnSale();

        logger.LogInformation(
            "GET /api/products/on-sale - Returning {Count} on-sale products", products.Count);

        return Ok(products);
    }

    /// <summary>Get top rated products.</summary>
    [HttpGet("top-rated")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    public IActionResult GetTopRated([FromQuery] int count = 5)
    {
        logger.LogInformation(
            "GET /api/products/top-rated - Request received, Count: {Count}", count);

        if (count <= 0 || count > 50)
        {
            logger.LogWarning(
                "GET /api/products/top-rated - Invalid count {Count} requested, clamping to valid range",
                count);
            count = Math.Clamp(count, 1, 50);
        }

        var products = productService.GetTopRated(count);

        logger.LogInformation(
            "GET /api/products/top-rated - Returning {Count} top-rated products", products.Count);

        return Ok(products);
    }

    /// <summary>Get a distinct list of all available brands.</summary>
    [HttpGet("brands")]
    [ProducesResponseType(typeof(List<string>), 200)]
    public IActionResult GetBrands()
    {
        logger.LogInformation("GET /api/products/brands - Request received");

        var brands = productService.GetAllBrands();

        logger.LogInformation(
            "GET /api/products/brands - Returning {Count} brands", brands.Count);

        return Ok(brands);
    }
}
