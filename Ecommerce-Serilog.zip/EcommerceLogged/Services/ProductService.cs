using Ecommerce.Data;
using Ecommerce.DTOs;
using Ecommerce.Models;
using Ecommerce.Services.Interfaces;
using Microsoft.Extensions.Logging;

namespace Ecommerce.Services;

public class ProductService(ILogger<ProductService> logger) : IProductService
{
    public PagedResult<ProductDto> GetAll(ProductFilterRequest filter)
    {
        logger.LogInformation(
            "Fetching products - Page: {Page}, PageSize: {PageSize}, Search: {Search}, " +
            "CategoryId: {CategoryId}, Brand: {Brand}, MinPrice: {MinPrice}, MaxPrice: {MaxPrice}, " +
            "SortBy: {SortBy}, SortOrder: {SortOrder}",
            filter.Page, filter.PageSize, filter.Search,
            filter.CategoryId, filter.Brand, filter.MinPrice, filter.MaxPrice,
            filter.SortBy, filter.SortOrder);

        var query = DataStore.Products.AsQueryable();

        // Filters
        if (filter.CategoryId.HasValue)
        {
            query = query.Where(p => p.CategoryId == filter.CategoryId.Value);
            logger.LogDebug("Applied category filter: {CategoryId}", filter.CategoryId.Value);
        }

        if (!string.IsNullOrWhiteSpace(filter.Brand))
        {
            query = query.Where(p => p.Brand.Equals(filter.Brand, StringComparison.OrdinalIgnoreCase));
            logger.LogDebug("Applied brand filter: {Brand}", filter.Brand);
        }

        if (filter.MinPrice.HasValue)
        {
            query = query.Where(p => (p.DiscountPrice ?? p.Price) >= filter.MinPrice.Value);
            logger.LogDebug("Applied min price filter: {MinPrice}", filter.MinPrice.Value);
        }

        if (filter.MaxPrice.HasValue)
        {
            query = query.Where(p => (p.DiscountPrice ?? p.Price) <= filter.MaxPrice.Value);
            logger.LogDebug("Applied max price filter: {MaxPrice}", filter.MaxPrice.Value);
        }

        if (!string.IsNullOrWhiteSpace(filter.Search))
        {
            query = query.Where(p =>
                p.Name.Contains(filter.Search, StringComparison.OrdinalIgnoreCase) ||
                p.Description.Contains(filter.Search, StringComparison.OrdinalIgnoreCase) ||
                p.Brand.Contains(filter.Search, StringComparison.OrdinalIgnoreCase));
            logger.LogDebug("Applied search filter: {Search}", filter.Search);
        }

        // Sorting
        query = (filter.SortBy.ToLower(), filter.SortOrder.ToLower()) switch
        {
            ("price",  "desc") => query.OrderByDescending(p => p.DiscountPrice ?? p.Price),
            ("price",  _)      => query.OrderBy(p => p.DiscountPrice ?? p.Price),
            ("rating", "desc") => query.OrderByDescending(p => p.Rating),
            ("rating", _)      => query.OrderBy(p => p.Rating),
            (_,        "desc") => query.OrderByDescending(p => p.Name),
            _                  => query.OrderBy(p => p.Name)
        };

        var total = query.Count();
        var items = query
            .Skip((filter.Page - 1) * filter.PageSize)
            .Take(filter.PageSize)
            .Select(MapToDto)
            .ToList();

        logger.LogInformation(
            "Successfully fetched {FetchedCount} products (Total matching: {TotalCount}, Page: {Page}/{TotalPages})",
            items.Count, total, filter.Page,
            (int)Math.Ceiling((double)total / filter.PageSize));

        return new PagedResult<ProductDto>
        {
            Items      = items,
            TotalCount = total,
            Page       = filter.Page,
            PageSize   = filter.PageSize
        };
    }

    public ProductDto? GetById(int id)
    {
        logger.LogInformation("Fetching product with ID: {ProductId}", id);

        var product = DataStore.Products.FirstOrDefault(p => p.Id == id);

        if (product is null)
        {
            logger.LogWarning("Product not found with ID: {ProductId}", id);
            return null;
        }

        logger.LogInformation("Successfully fetched product: {ProductName} (ID: {ProductId})",
            product.Name, product.Id);

        return MapToDto(product);
    }

    public List<ProductDto> GetByCategory(int categoryId)
    {
        logger.LogInformation("Fetching products for CategoryId: {CategoryId}", categoryId);

        var products = DataStore.Products
            .Where(p => p.CategoryId == categoryId)
            .Select(MapToDto)
            .ToList();

        logger.LogInformation(
            "Successfully fetched {Count} products for CategoryId: {CategoryId}",
            products.Count, categoryId);

        return products;
    }

    public List<ProductDto> GetOnSale()
    {
        logger.LogInformation("Fetching all on-sale products");

        var products = DataStore.Products
            .Where(p => p.DiscountPrice.HasValue)
            .OrderBy(p => p.Name)
            .Select(MapToDto)
            .ToList();

        logger.LogInformation("Successfully fetched {Count} on-sale products", products.Count);

        return products;
    }

    public List<ProductDto> GetTopRated(int count = 5)
    {
        logger.LogInformation("Fetching top {Count} rated products", count);

        var products = DataStore.Products
            .OrderByDescending(p => p.Rating)
            .Take(count)
            .Select(MapToDto)
            .ToList();

        logger.LogInformation("Successfully fetched {Count} top-rated products", products.Count);

        return products;
    }

    public List<string> GetAllBrands()
    {
        logger.LogInformation("Fetching all distinct brands");

        var brands = DataStore.Products
            .Select(p => p.Brand)
            .Distinct()
            .OrderBy(b => b)
            .ToList();

        logger.LogInformation("Successfully fetched {Count} brands", brands.Count);

        return brands;
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private static ProductDto MapToDto(Product p)
    {
        var category = DataStore.Categories.FirstOrDefault(c => c.Id == p.CategoryId);
        return new ProductDto
        {
            Id            = p.Id,
            Name          = p.Name,
            Description   = p.Description,
            Price         = p.Price,
            DiscountPrice = p.DiscountPrice,
            Stock         = p.Stock,
            CategoryId    = p.CategoryId,
            CategoryName  = category?.Name ?? "Unknown",
            Brand         = p.Brand,
            ImageUrl      = p.ImageUrl,
            Rating        = p.Rating,
            ReviewCount   = p.ReviewCount
        };
    }
}
