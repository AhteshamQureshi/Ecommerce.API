using Ecommerce.Data;
using Ecommerce.DTOs;
using Ecommerce.Services.Interfaces;
using Microsoft.Extensions.Logging;

namespace Ecommerce.Services;

public class CategoryService(ILogger<CategoryService> logger) : ICategoryService
{
    public List<CategoryDto> GetAll()
    {
        logger.LogInformation("Fetching all categories");

        var categories = DataStore.Categories.Select(c => new CategoryDto
        {
            Id           = c.Id,
            Name         = c.Name,
            Description  = c.Description,
            ImageUrl     = c.ImageUrl,
            ProductCount = DataStore.Products.Count(p => p.CategoryId == c.Id)
        }).ToList();

        logger.LogInformation("Successfully fetched {Count} categories", categories.Count);

        return categories;
    }

    public CategoryDto? GetById(int id)
    {
        logger.LogInformation("Fetching category with ID: {CategoryId}", id);

        var c = DataStore.Categories.FirstOrDefault(c => c.Id == id);

        if (c is null)
        {
            logger.LogWarning("Category not found with ID: {CategoryId}", id);
            return null;
        }

        logger.LogInformation("Successfully fetched category: {CategoryName} (ID: {CategoryId})",
            c.Name, c.Id);

        return new CategoryDto
        {
            Id           = c.Id,
            Name         = c.Name,
            Description  = c.Description,
            ImageUrl     = c.ImageUrl,
            ProductCount = DataStore.Products.Count(p => p.CategoryId == c.Id)
        };
    }
}
