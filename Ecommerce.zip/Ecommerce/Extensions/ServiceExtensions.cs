using Ecommerce.Services;
using Ecommerce.Services.Interfaces;
using Microsoft.OpenApi.Models;

namespace Ecommerce.Extensions;

public static class ServiceExtensions
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        services.AddScoped<ICategoryService, CategoryService>();
        services.AddScoped<IProductService, ProductService>();
        return services;
    }

    public static IServiceCollection AddSwaggerDocs(this IServiceCollection services)
    {
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo
            {
                Title       = "Ecommerce Read-Only API",
                Version     = "v1",
                Description = "Public GET-only API for browsing categories and products. No authentication required."
            });
        });
        return services;
    }
}
