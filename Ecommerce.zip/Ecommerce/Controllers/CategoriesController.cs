using Ecommerce.DTOs;
using Ecommerce.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class CategoriesController(ICategoryService categoryService) : ControllerBase
{
    /// <summary>Get all categories with product count.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<CategoryDto>), 200)]
    public IActionResult GetAll()
    {
        var categories = categoryService.GetAll();
        return Ok(categories);
    }

    /// <summary>Get a single category by ID.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(CategoryDto), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetById(int id)
    {
        var category = categoryService.GetById(id);
        if (category is null)
            return NotFound(new { message = $"Category {id} not found." });

        return Ok(category);
    }

    /// <summary>Get all products belonging to a category.</summary>
    [HttpGet("{id:int}/products")]
    [ProducesResponseType(typeof(List<ProductDto>), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetProducts(int id, [FromServices] IProductService productService)
    {
        var category = categoryService.GetById(id);
        if (category is null)
            return NotFound(new { message = $"Category {id} not found." });

        var products = productService.GetByCategory(id);
        return Ok(products);
    }
}
