using Ecommerce.Data;
using Ecommerce.DTOs;
using Ecommerce.Models;
using Ecommerce.Services.Interfaces;

namespace Ecommerce.Services;

public class ProductService : IProductService
{
    public PagedResult<ProductDto> GetAll(ProductFilterRequest filter)
    {
        var query = DataStore.Products.AsQueryable();

        // Filters
        if (filter.CategoryId.HasValue)
            query = query.Where(p => p.CategoryId == filter.CategoryId.Value);

        if (!string.IsNullOrWhiteSpace(filter.Brand))
            query = query.Where(p => p.Brand.Equals(filter.Brand, StringComparison.OrdinalIgnoreCase));

        if (filter.MinPrice.HasValue)
            query = query.Where(p => (p.DiscountPrice ?? p.Price) >= filter.MinPrice.Value);

        if (filter.MaxPrice.HasValue)
            query = query.Where(p => (p.DiscountPrice ?? p.Price) <= filter.MaxPrice.Value);

        if (!string.IsNullOrWhiteSpace(filter.Search))
            query = query.Where(p =>
                p.Name.Contains(filter.Search, StringComparison.OrdinalIgnoreCase) ||
                p.Description.Contains(filter.Search, StringComparison.OrdinalIgnoreCase) ||
                p.Brand.Contains(filter.Search, StringComparison.OrdinalIgnoreCase));

        // Sorting
        query = (filter.SortBy.ToLower(), filter.SortOrder.ToLower()) switch
        {
            ("price",  "desc") => query.OrderByDescending(p => p.DiscountPrice ?? p.Price),
            ("price",  _)      => query.OrderBy(p => p.DiscountPrice ?? p.Price),
            ("rating", "desc") => query.OrderByDescending(p => p.Rating),
            ("rating", _)      => query.OrderBy(p => p.Rating),
            (_,        "desc") => query.OrderByDescending(p => p.Name),
            _                  => query.OrderBy(p => p.Name)
        };

        var total = query.Count();
        var items = query
            .Skip((filter.Page - 1) * filter.PageSize)
            .Take(filter.PageSize)
            .Select(MapToDto)
            .ToList();

        return new PagedResult<ProductDto>
        {
            Items      = items,
            TotalCount = total,
            Page       = filter.Page,
            PageSize   = filter.PageSize
        };
    }

    public ProductDto? GetById(int id)
    {
        var product = DataStore.Products.FirstOrDefault(p => p.Id == id);
        return product is null ? null : MapToDto(product);
    }

    public List<ProductDto> GetByCategory(int categoryId)
    {
        return DataStore.Products
            .Where(p => p.CategoryId == categoryId)
            .Select(MapToDto)
            .ToList();
    }

    public List<ProductDto> GetOnSale()
    {
        return DataStore.Products
            .Where(p => p.DiscountPrice.HasValue)
            .OrderBy(p => p.Name)
            .Select(MapToDto)
            .ToList();
    }

    public List<ProductDto> GetTopRated(int count = 5)
    {
        return DataStore.Products
            .OrderByDescending(p => p.Rating)
            .Take(count)
            .Select(MapToDto)
            .ToList();
    }

    public List<string> GetAllBrands()
    {
        return DataStore.Products
            .Select(p => p.Brand)
            .Distinct()
            .OrderBy(b => b)
            .ToList();
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private static ProductDto MapToDto(Product p)
    {
        var category = DataStore.Categories.FirstOrDefault(c => c.Id == p.CategoryId);
        return new ProductDto
        {
            Id           = p.Id,
            Name         = p.Name,
            Description  = p.Description,
            Price        = p.Price,
            DiscountPrice = p.DiscountPrice,
            Stock        = p.Stock,
            CategoryId   = p.CategoryId,
            CategoryName = category?.Name ?? "Unknown",
            Brand        = p.Brand,
            ImageUrl     = p.ImageUrl,
            Rating       = p.Rating,
            ReviewCount  = p.ReviewCount
        };
    }
}
